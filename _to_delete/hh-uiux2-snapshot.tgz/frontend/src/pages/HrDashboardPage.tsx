import { useEffect, useState } from 'react';
import { Alert, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { getHhConnectionStatus, getHhDashboard } from '../services/hh.api';
import type { HhCandidateStage, HhConnectionDto, HhDashboardDto, HhVacancyStatus } from '../types/hh';
import '../styles/hr-cabinet.css';

const stageLabels: Record<HhCandidateStage, string> = {
  new: 'Новый отклик',
  screening: 'Скрининг',
  phone_interview: 'Телефонное интервью',
  submitted_to_manager: 'У руководителя',
  manager_interview: 'Интервью с заказчиком',
  offer: 'Оффер',
  hired: 'Принят',
  rejected: 'Отказ',
};

/**
 * Колонки матрицы «вакансия x этап»: смежные этапы схлопнуты,
 * чтобы сетка читалась одним взглядом (как в референсных ATS).
 */
const MATRIX_COLUMNS: Array<{ key: string; label: string; stages: HhCandidateStage[] }> = [
  { key: 'new', label: 'Новые', stages: ['new'] },
  { key: 'screening', label: 'Скрининг', stages: ['screening', 'phone_interview'] },
  { key: 'manager', label: 'У заказчика', stages: ['submitted_to_manager', 'manager_interview'] },
  { key: 'offer', label: 'Оффер', stages: ['offer'] },
  { key: 'hired', label: 'Принят', stages: ['hired'] },
];

const VACANCY_STATUS_META: Record<HhVacancyStatus, { label: string; color: string }> = {
  open: { label: 'Открытые', color: '#66bb6a' },
  paused: { label: 'На паузе', color: '#ffb74d' },
  draft: { label: 'Черновики', color: '#b0bec5' },
  closed: { label: 'Закрытые', color: '#9575cd' },
  archived: { label: 'Архив', color: '#cfd8dc' },
};

export default function HrDashboardPage() {
  const navigate = useNavigate();
  const [connection, setConnection] = useState<HhConnectionDto | null>(null);
  const [dashboard, setDashboard] = useState<HhDashboardDto | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    Promise.all([getHhConnectionStatus(), getHhDashboard()])
      .then(([connectionResponse, dashboardResponse]) => {
        setConnection(connectionResponse.data);
        setDashboard(dashboardResponse.data);
      })
      .catch((err) => setError(err?.response?.data?.message || err?.message || 'Не удалось загрузить кабинет HR'))
      .finally(() => setIsLoading(false));
  }, []);

  const metrics = dashboard?.metrics;
  const metricValue = (value: number | undefined) => isLoading ? '...' : String(value ?? 0);

  return (
    <div className="hr-page">
      <section className="hr-page__header">
        <div>
          <h1 className="hr-page__title">Кабинет HR</h1>
          <p className="hr-page__subtitle">Вакансии, отклики, кандидаты, интервью и отчётность по найму.</p>
        </div>
        <span className="hr-page__status">
          {connection?.status === 'active' ? 'hh.ru подключён' : 'hh.ru не подключён'}
        </span>
      </section>
      {error && <Alert severity="warning">{error}</Alert>}
      {!connection?.configured && (
        <Alert severity="info">Интеграция hh.ru ещё не настроена. Пока можно вести вакансии и кандидатов вручную.</Alert>
      )}
      <section className="hr-page__grid">
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.openVacancies)}</div><div className="hr-page__label">Открытых вакансий</div></div>
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.responses)}</div><div className="hr-page__label">Новых откликов</div></div>
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.activeCandidates)}</div><div className="hr-page__label">Кандидатов в работе</div></div>
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.weeklyInterviews)}</div><div className="hr-page__label">Интервью на неделе</div></div>
      </section>
      {dashboard?.tasks && (
        <section className="hr-tasks">
          <div className="hr-tasks__col hr-tasks__col--new">
            <header>
              <span>Новые заявки</span>
              <strong className={dashboard.tasks.newRequests.total > 0 ? 'hr-tasks__count hr-tasks__count--hot' : 'hr-tasks__count'}>
                {dashboard.tasks.newRequests.total}
              </strong>
            </header>
            {dashboard.tasks.newRequests.items.map((request) => (
              <button key={request.id} type="button" className="hr-tasks__item"
                onClick={() => navigate(`/hr/requests?requestId=${request.id}`)}>
                <span>{request.position}</span>
                <small>{request.createdByName || 'автор не указан'}</small>
              </button>
            ))}
            {dashboard.tasks.newRequests.total === 0 && <span className="hr-page__empty">Все заявки в работе.</span>}
          </div>
          <div className="hr-tasks__col hr-tasks__col--wait">
            <header>
              <span>Ждут решения заказчика</span>
              <strong className={dashboard.tasks.pendingDecisions.total > 0 ? 'hr-tasks__count hr-tasks__count--warm' : 'hr-tasks__count'}>
                {dashboard.tasks.pendingDecisions.total}
              </strong>
            </header>
            {dashboard.tasks.pendingDecisions.items.map((row) => (
              <button key={row.requestId} type="button" className="hr-tasks__item"
                onClick={() => navigate(`/hr/requests?requestId=${row.requestId}`)}>
                <span>{row.position}</span>
                <small>{row.pending} чел. на рассмотрении</small>
              </button>
            ))}
            {dashboard.tasks.pendingDecisions.total === 0 && <span className="hr-page__empty">Никто не ждёт.</span>}
          </div>
          <div className="hr-tasks__col hr-tasks__col--today">
            <header>
              <span>Интервью сегодня</span>
              <strong className="hr-tasks__count">{dashboard.tasks.interviewsToday.length}</strong>
            </header>
            {dashboard.tasks.interviewsToday.map((interview) => (
              <button key={`${interview.candidateId}-${interview.dueAt}`} type="button" className="hr-tasks__item"
                onClick={() => navigate(`/hr/candidates?candidateId=${interview.candidateId}`)}>
                <span>
                  {new Date(interview.dueAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                  {' '}{interview.candidateName}
                </span>
                <small>{interview.vacancyTitle || 'без вакансии'}</small>
              </button>
            ))}
            {dashboard.tasks.interviewsToday.length === 0 && <span className="hr-page__empty">Сегодня интервью нет.</span>}
          </div>
        </section>
      )}
      {(dashboard?.pipeline?.length ?? 0) > 0 && (
        <section className="hr-matrix">
          <header className="hr-matrix__header">
            <span className="hr-page__section-title">Подбор по вакансиям</span>
            <Button size="small" variant="text" onClick={() => navigate('/hr/vacancies')}>Все вакансии</Button>
          </header>
          <div className="hr-matrix__table-wrap">
            <table className="hr-matrix__table">
              <thead>
                <tr>
                  <th>Вакансия</th>
                  {MATRIX_COLUMNS.map((column) => <th key={column.key}>{column.label}</th>)}
                </tr>
              </thead>
              <tbody>
                {(dashboard?.pipeline ?? []).map((row) => (
                  <tr key={row.vacancyId}>
                    <td>
                      <button
                        type="button"
                        className="hr-matrix__vacancy"
                        title="Открыть кандидатов по вакансии"
                        onClick={() => navigate(`/hr/candidates?vacancyId=${row.vacancyId}`)}
                      >
                        <strong>{row.vacancyTitle}</strong>
                        <small>в работе: {row.total}</small>
                      </button>
                    </td>
                    {MATRIX_COLUMNS.map((column) => {
                      const count = column.stages.reduce((sum, stage) => sum + (row.stages[stage] ?? 0), 0);
                      if (count === 0) {
                        return <td key={column.key}><span className="hr-matrix__cell hr-matrix__cell--empty" /></td>;
                      }
                      const stageQuery = column.stages.length === 1 ? `&stage=${column.stages[0]}` : '';
                      return (
                        <td key={column.key}>
                          <button
                            type="button"
                            className={`hr-matrix__cell hr-matrix__cell--${column.key}`}
                            title={`${column.label}: открыть список`}
                            onClick={() => navigate(`/hr/candidates?vacancyId=${row.vacancyId}${stageQuery}`)}
                          >
                            {count} канд.
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
      <section className="hr-page__grid hr-page__grid--triple">
        <div className="hr-page__card">
          <div className="hr-page__section-title">Вакансии</div>
          {(() => {
            const summary = dashboard?.vacancySummary ?? [];
            const summaryTotal = summary.reduce((sum, row) => sum + row.count, 0);
            let acc = 0;
            const stops = summary.map((row) => {
              const from = (acc / Math.max(1, summaryTotal)) * 360;
              acc += row.count;
              const to = (acc / Math.max(1, summaryTotal)) * 360;
              return `${VACANCY_STATUS_META[row.status].color} ${from}deg ${to}deg`;
            }).join(', ');
            return (
              <div className="hr-donut__wrap">
                <div
                  className="hr-donut"
                  style={{ background: summaryTotal > 0 ? `conic-gradient(${stops})` : '#eceff1' }}
                >
                  <div className="hr-donut__hole">
                    <strong>{summaryTotal}</strong>
                    <small>вакансий</small>
                  </div>
                </div>
                <div className="hr-donut__legend">
                  {summary.map((row) => (
                    <span key={row.status}>
                      <i style={{ background: VACANCY_STATUS_META[row.status].color }} />
                      {VACANCY_STATUS_META[row.status].label}: <strong>{row.count}</strong>
                    </span>
                  ))}
                  {summary.length === 0 && <span className="hr-page__empty">Вакансий пока нет.</span>}
                </div>
              </div>
            );
          })()}
        </div>
        <div className="hr-page__card">
          <div className="hr-page__section-title">Воронка</div>
          <div className="hr-funnel">
            {isLoading ? <div className="hr-page__empty">Загрузка...</div> : (dashboard?.stages ?? []).length > 0 ? (() => {
              const stages = dashboard?.stages ?? [];
              const max = Math.max(1, ...stages.map((item) => item.count));
              return stages.map((item) => (
                <div className="hr-funnel__row" key={item.stage}>
                  <span className="hr-funnel__label">{item.label}</span>
                  <span className="hr-funnel__bar">
                    <i
                      className={`hr-funnel__fill hr-funnel__fill--${item.stage}`}
                      style={{ width: `${Math.max(6, Math.round((item.count / max) * 100))}%` }}
                    />
                  </span>
                  <strong>{item.count}</strong>
                </div>
              ));
            })() : <div className="hr-page__empty">Пока нет кандидатов в работе.</div>}
          </div>
        </div>
        <div className="hr-page__card">
          <div className="hr-page__section-title">Последние кандидаты</div>
          <div className="hr-page__stage-list">
            {isLoading ? <div className="hr-page__empty">Загрузка...</div> : (dashboard?.recentCandidates ?? []).length > 0 ? dashboard?.recentCandidates.map((candidate) => (
              <div className="hr-page__stage-row" key={candidate.id}>
                <span>{candidate.fullName}<small>{candidate.vacancyTitle ? ` · ${candidate.vacancyTitle}` : ''}</small></span>
                <strong>{stageLabels[candidate.currentStage]}</strong>
              </div>
            )) : <div className="hr-page__empty">Добавьте первого кандидата вручную или подключите импорт откликов.</div>}
          </div>
        </div>
      </section>
      <section className="hr-page__actions">
        <Button variant="contained" onClick={() => navigate('/hr/vacancies')}>Открыть вакансии</Button>
        <Button variant="outlined" onClick={() => navigate('/hr/candidates')}>Открыть кандидатов</Button>
      </section>
    </div>
  );
}
