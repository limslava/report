import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import fs from 'fs';
import path from 'path';
import { authRouter } from './routes/auth.routes';
import { adminRouter } from './routes/admin.routes';
import emailRouter from './routes/email.routes';
import smtpConfigRouter from './routes/smtp-config.routes';
import { notesRouter } from './routes/notes.routes';
import { usersRouter } from './routes/users.routes';
import { planningV2Router } from './routes/planning-v2.routes';
import { financialPlanRouter } from './routes/financial-plan.routes';
import { operationsPreviewRouter } from './routes/operations-preview.routes';
import { contractsRouter } from './routes/contracts.routes';
import { candidateChecksRouter } from './routes/candidate-checks.routes';
import { counterpartiesRouter } from './routes/counterparties.routes';
import { carriersRouter } from './routes/carriers.routes';
import { warehouseRouter } from './routes/warehouse.routes';
import { hhRouter } from './routes/hh.routes';
import { getHhModuleHealth } from './controllers/hh-settings.controller';
import { receiveHhWebhook } from './controllers/hh-webhooks.controller';
import { errorHandler } from './middleware/error-handler';
import { logger } from './utils/logger';
import { getAllowedCorsOrigins, isAllowedCorsOrigin } from './config/env';
import { createRateLimiter } from './middleware/rate-limit';
import { authenticate } from './middleware/authenticate';
import { authorizeRole } from './middleware/authorize';
import { withRetry } from './utils/db-retry';
import { dbCircuit } from './utils/db-circuit';
import { AppDataSource } from './config/data-source';
import { dbMetrics } from './utils/db-metrics';
import { canConnectRedis, getSchedulerStatus, isRedisRequiredForScheduler } from './services/scheduler';
import { createWarehouseTusServer } from './services/warehouse-tus.service';
import { WAREHOUSE_STAFF_ROLES } from './constants/warehouse';

export function createApp() {
  const app = express();
  const allowedOrigins = getAllowedCorsOrigins();
  const trustProxyValue = process.env.TRUST_PROXY ?? '1';
  app.set('trust proxy', trustProxyValue);
  const apiRateLimiter = createRateLimiter({
    windowMs: 60 * 1000,
    max: 120,
    message: 'Слишком много запросов. Повторите позже.',
  });

  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        'frame-src': ["'self'", 'blob:'],
      },
    },
  }));
  app.use(cors({
    origin: (origin, callback) => {
      if (isAllowedCorsOrigin(origin, allowedOrigins)) {
        return callback(null, true);
      }
      return callback(new Error('CORS origin is not allowed'));
    },
    credentials: true,
  }));
  app.use(compression());
  let warehouseTusServerPromise: ReturnType<typeof createWarehouseTusServer> | null = null;
  const handleWarehouseTusUpload = async (req: express.Request, res: express.Response) => {
    warehouseTusServerPromise ??= createWarehouseTusServer();
    const warehouseTusServer = await warehouseTusServerPromise;
    warehouseTusServer.handle(req, res);
  };
  app.all('/api/warehouse/uploads', authenticate, authorizeRole(...WAREHOUSE_STAFF_ROLES), handleWarehouseTusUpload);
  app.all('/api/warehouse/uploads/*', authenticate, authorizeRole(...WAREHOUSE_STAFF_ROLES), handleWarehouseTusUpload);
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use('/api', (req, res, next) => {
    if (req.path.startsWith('/warehouse/uploads') || req.path.startsWith('/hh/webhooks/')) {
      return next();
    }
    return apiRateLimiter(req, res, next);
  });

  app.use((req, _res, next) => {
    if (process.env.NODE_ENV === 'test') {
      return next();
    }
    const pathLower = req.path.toLowerCase();
    const isStaticAsset =
      pathLower === '/vite.svg' ||
      pathLower.startsWith('/assets/') ||
      pathLower === '/favicon.ico';

    if (!isStaticAsset) {
      logger.info(`${req.method} ${req.url}`);
    }
    next();
  });

  app.use('/api', (_req, res, next) => {
    if (dbCircuit.isOpen() || !dbCircuit.canPass()) {
      res.status(503).json({
        error: 'Service Unavailable',
        message: 'Database temporarily unavailable. Please try again later.',
        statusCode: 503,
      });
      return;
    }

    res.on('finish', () => {
      if (res.statusCode < 500 && res.statusCode !== 503 && res.statusCode !== 429) {
        dbCircuit.recordSuccess();
      }
    });

    next();
  });

  // Приёмник вебхуков hh: без JWT (запрос приходит от hh), но со своим лимитером.
  // Исключён из общего apiRateLimiter выше, поэтому лимит нужен здесь.
  const hhWebhookRateLimiter = createRateLimiter({
    windowMs: 60 * 1000,
    max: 600,
    message: 'Слишком много webhook-запросов hh.',
  });
  app.post('/api/hh/webhooks/:secret', hhWebhookRateLimiter, receiveHhWebhook);

  app.use('/api/auth', authRouter);
  app.use('/api/v2/planning', planningV2Router);
  app.use('/api/v2/financial-plan', financialPlanRouter);
  app.use('/api/admin', adminRouter);
  app.use('/api/users', usersRouter);
  app.use('/api/email-schedules', emailRouter);
  app.use('/api/smtp-config', smtpConfigRouter);
  app.use('/api/notes', notesRouter);
  app.use('/api/operations-preview', operationsPreviewRouter);
  app.use('/api/contracts', contractsRouter);
  app.use('/api/candidate-checks', candidateChecksRouter);
  app.use('/api/counterparties', counterpartiesRouter);
  app.use('/api/carriers', carriersRouter);
  app.use('/api/warehouse', warehouseRouter);
  app.use('/api/hh', hhRouter);

  app.get('/health', (_req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
  });

  app.get('/health/db', async (_req, res) => {
    if (!AppDataSource.isInitialized) {
      dbMetrics.recordError('Datasource not initialized');
      res.status(503).json({ status: 'DOWN', reason: 'Datasource not initialized' });
      return;
    }

    try {
      const startedAt = Date.now();
      await withRetry(async () => {
        let timer: NodeJS.Timeout | null = null;
        try {
          const timeoutPromise = new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error('DB health timeout')), 2000);
          });
          return await Promise.race([AppDataSource.query('SELECT 1'), timeoutPromise]);
        } finally {
          if (timer) {
            clearTimeout(timer);
          }
        }
      }, { attempts: 2, baseDelayMs: 200, maxDelayMs: 1000 });
      const latencyMs = Date.now() - startedAt;
      dbMetrics.recordLatency(latencyMs);
      res.json({ status: 'OK', latencyMs });
    } catch (err: any) {
      dbMetrics.recordError(err?.message || 'DB health check failed');
      res.status(503).json({ status: 'DOWN', error: err?.message || 'DB health check failed' });
    }
  });

  app.get('/health/db/metrics', (_req, res) => {
    res.json(dbMetrics.snapshot());
  });

  // Отдаёт конфигурацию интеграции и телеметрию — только администратору.
  app.get('/health/hh', authenticate, authorizeRole('admin'), getHhModuleHealth);

  app.get('/health/redis', async (_req, res) => {
    if (!isRedisRequiredForScheduler()) {
      res.json({
        status: 'NOT_REQUIRED',
        reason: 'Redis queue is disabled for scheduler in current environment',
      });
      return;
    }
    try {
      const ok = await canConnectRedis();
      if (!ok) {
        logger.warn('Redis health check failed');
        res.status(503).json({ status: 'DOWN' });
        return;
      }
      res.json({ status: 'OK' });
    } catch (error: any) {
      logger.warn('Redis health check error', error);
      res.status(503).json({ status: 'DOWN', error: error?.message || 'Redis health check failed' });
    }
  });

  app.get('/health/scheduler', (_req, res) => {
    const status = getSchedulerStatus();
    if (!status.schedulerEnabled) {
      res.status(503).json({ status: 'DOWN', ...status });
      return;
    }
    res.json({ status: 'OK', ...status });
  });

  const frontendDistPath = path.resolve(process.cwd(), 'frontend', 'dist');
  const frontendIndexPath = path.join(frontendDistPath, 'index.html');
  if (fs.existsSync(frontendIndexPath)) {
    app.use(
      express.static(frontendDistPath, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith(`${path.sep}index.html`)) {
            res.setHeader('Cache-Control', 'no-cache');
            return;
          }
          if (filePath.includes(`${path.sep}assets${path.sep}`)) {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          }
        },
      })
    );
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api') || req.path === '/health' || req.path === '/health/db') {
        return next();
      }
      res.setHeader('Cache-Control', 'no-cache');
      return res.sendFile(frontendIndexPath);
    });
  }

  app.use('*', (_req, res) => {
    res.status(404).json({ error: 'Not Found' });
  });

  app.use(errorHandler);

  return app;
}
