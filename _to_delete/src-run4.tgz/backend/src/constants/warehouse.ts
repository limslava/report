export const WAREHOUSE_ACCESS_ROLES = [
  'admin',
  'director',
  'general_director',
  'financer',
  'warehouse_manager',
  'warehouse_keeper',
  'counterparty_user',
] as const;

export const WAREHOUSE_STAFF_ROLES = [
  'admin',
  'warehouse_manager',
  'warehouse_keeper',
] as const;

export const WAREHOUSE_DATE_CORRECTION_ROLES = [
  'admin',
  'warehouse_manager',
] as const;

export const WAREHOUSE_CLIENT_MANAGEMENT_ROLES = [
  'admin',
  'warehouse_manager',
] as const;

export const WAREHOUSE_TARIFF_MANAGEMENT_ROLES = [
  'admin',
  'warehouse_manager',
  'financer',
] as const;

export const WAREHOUSE_SERVICE_EXECUTION_ROLES = [
  'admin',
  'warehouse_manager',
  'warehouse_keeper',
  'financer',
] as const;

export const WAREHOUSE_BILLING_MANAGEMENT_ROLES = [
  'admin',
  'warehouse_manager',
  'financer',
] as const;

export const WAREHOUSE_BILLING_VIEW_ROLES = [
  'admin',
  'director',
  'general_director',
  'financer',
  'warehouse_manager',
  'counterparty_user',
] as const;

export const WAREHOUSE_VEHICLE_TYPES = [
  'passenger',
  'light_commercial',
  'truck',
  'trailer',
  'special',
  'motorcycle',
] as const;

export type WarehouseVehicleTypeCode = typeof WAREHOUSE_VEHICLE_TYPES[number];

export const WAREHOUSE_VEHICLE_TYPE_LABELS: Record<WarehouseVehicleTypeCode, string> = {
  passenger: 'Легковой автомобиль',
  light_commercial: 'Легковой коммерческий автомобиль',
  truck: 'Грузовая техника',
  trailer: 'Прицеп / полуприцеп',
  special: 'Спецтехника',
  motorcycle: 'Мото-техника',
};

export type WarehouseAccessRole = typeof WAREHOUSE_ACCESS_ROLES[number];
