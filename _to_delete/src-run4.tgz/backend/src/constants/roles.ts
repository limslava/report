export const DEPARTMENT_FULL_ACCESS_ROLES = ['admin', 'director', 'general_director', 'financer'] as const;
export const PLANNING_FULL_ACCESS_ROLES = ['admin', 'director', 'general_director', 'manager_sales', 'head_sales', 'financer'] as const;
export const DEPARTMENT_ROLES = [
  'manager_ktk_vvo',
  'head_ktk_vvo',
  'manager_ktk_mow',
  'head_ktk_mow',
  'manager_auto',
  'manager_rail',
  'manager_extra',
  'manager_to',
  'manager_sales',
  'head_sales',
] as const;
