import { AppDataSource } from '../config/data-source';
import { PlanningDailyValue } from '../models/planning-daily-value.model';
import { PlanningMetric } from '../models/planning-metric.model';
import { PlanningMetricAggregation, PlanningPlanMetricCode, PlanningSegmentCode } from '../models/planning.enums';
import { PlanningMonthlyPlan } from '../models/planning-monthly-plan.model';
import { PlanningMonthlyPlanMetric } from '../models/planning-monthly-plan-metric.model';
import { PlanningSegment } from '../models/planning-segment.model';
import { OperationsPreviewState } from '../models/operations-preview-state.model';

interface SegmentReportParams {
  segmentCode: PlanningSegmentCode;
  year: number;
  month: number;
  asOfDate?: string;
}

type OpsPreviewDepartment = 'Контейнеры' | 'Авто' | 'Диспетчера' | 'Курьеры';
type OpsPreviewCellCode = 'W' | 'O' | 'B' | 'H' | 'R' | 'N' | 'V' | 'E' | 'S';
type OpsPreviewScopeKey = `${'plan' | 'fact'}|${string}`;
type OpsPreviewPersonRow = {
  id: string;
  secondName?: string;
  department: OpsPreviewDepartment;
  plate?: string;
};
type OpsPreviewPersistedState = {
  overrides?: Record<OpsPreviewScopeKey, Record<string, OpsPreviewCellCode>>;
  peopleByMonth?: Record<string, OpsPreviewPersonRow[]>;
  peopleState?: OpsPreviewPersonRow[];
  monthValue?: string;
};

interface DashboardBase {
  asOfDate: string;
  daysInMonth: number;
  completedDays: number;
}

interface AutoPreviewEfficiency {
  uniquePlatesCount: number;
  workAutoDays: number;
  cargoRemovalDays: number;
  unloadFactor: number;
  avgTripDuration: number;
}

export interface PlanningGridRow {
  metricCode: string;
  name: string;
  isEditable: boolean;
  aggregation: PlanningMetricAggregation;
  dayValues: Array<number | null>;
  monthTotal: number;
}

export type SegmentDashboard = DashboardBase & Record<string, unknown>;
type SummaryRow = {
  segmentCode: PlanningSegmentCode;
  segmentName: string;
  planMonth: number;
  planToDate: number;
  factToDate: number;
  monthFact: number;
  completionToDate: number;
  completionMonth: number;
  parentSegmentCode?: PlanningSegmentCode;
  detailCode?: string;
};

function toIsoDate(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function parseIsoDate(value: string): Date {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day));
}

function getDaysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function safeNumber(value: number | null | undefined): number {
  return value ?? 0;
}

function sum(values: Array<number | null>): number {
  return values.reduce<number>((acc, value) => acc + safeNumber(value), 0);
}

function sumUntil(values: Array<number | null>, dayCount: number): number {
  return values.slice(0, dayCount).reduce<number>((acc, value) => acc + safeNumber(value), 0);
}

function avgUntil(values: Array<number | null>, dayCount: number): number {
  if (dayCount <= 0) {
    return 0;
  }

  const total = sumUntil(values, dayCount);
  return total / dayCount;
}

function lastUntil(values: Array<number | null>, dayCount: number): number {
  for (let i = Math.min(dayCount - 1, values.length - 1); i >= 0; i -= 1) {
    if (values[i] !== null) {
      return values[i] as number;
    }
  }
  return 0;
}

function pct(part: number, total: number): number {
  if (total <= 0) {
    return 0;
  }
  return (part / total) * 100;
}

function calcPlanToDate(planMonth: number, daysInMonth: number, completedDays: number): number {
  if (daysInMonth <= 0 || completedDays <= 0) {
    return 0;
  }

  const raw = (planMonth / daysInMonth) * completedDays;
  const rounded = Math.round(raw);

  if (completedDays >= daysInMonth) {
    return Math.min(rounded, planMonth);
  }

  return rounded;
}

function isWaitingMetricCode(metricCode: string): boolean {
  return metricCode === 'auto_truck_waiting'
    || metricCode === 'auto_ktk_waiting'
    || metricCode === 'auto_curtain_waiting'
    || metricCode === 'auto_total_waiting'
    || metricCode === 'rail_total_waiting';
}

function isKtkGrossMetricCode(metricCode: string): boolean {
  return metricCode === 'ktk_vvo_manual_gross' || metricCode === 'ktk_mow_manual_gross';
}

function getPlanValue(planMetricMap: Map<PlanningPlanMetricCode, PlanningMonthlyPlanMetric>, code: PlanningPlanMetricCode): number {
  const planMetric = planMetricMap.get(code);
  if (!planMetric) {
    return 0;
  }

  if (planMetric.carryPlan !== null && planMetric.carryPlan !== undefined) {
    return planMetric.carryPlan;
  }

  return planMetric.basePlan ?? 0;
}

function topLevelSummaryName(segmentCode: PlanningSegmentCode, fallback: string): string {
  if (segmentCode === PlanningSegmentCode.KTK_VVO || segmentCode === PlanningSegmentCode.KTK_MOW) {
    return 'КТК';
  }
  if (segmentCode === PlanningSegmentCode.RAIL) {
    return 'ЖД';
  }
  if (segmentCode === PlanningSegmentCode.TO) {
    return 'ТО авто';
  }
  return fallback;
}

export class PlanningV2ReportService {
  private readonly segmentRepo = AppDataSource.getRepository(PlanningSegment);
  private readonly metricRepo = AppDataSource.getRepository(PlanningMetric);
  private readonly valuesRepo = AppDataSource.getRepository(PlanningDailyValue);
  private readonly monthlyPlanRepo = AppDataSource.getRepository(PlanningMonthlyPlan);
  private readonly operationsPreviewRepo = AppDataSource.getRepository(OperationsPreviewState);
  private readonly operationsPreviewScopeKey = 'ktk_vvo_preview_v1';

  private isKtkVvoTrucksOnLineAutoFromPreview(year: number, month: number): boolean {
    return year > 2026 || (year === 2026 && month >= 5);
  }

  private getPrevMonthValue(value: string): string | null {
    const [yearRaw, monthRaw] = value.split('-');
    const year = Number(yearRaw);
    const month = Number(monthRaw);
    if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) return null;
    if (month === 1) return `${year - 1}-12`;
    return `${year}-${String(month - 1).padStart(2, '0')}`;
  }

  private extractPeopleByMonth(payload: OpsPreviewPersistedState): Record<string, OpsPreviewPersonRow[]> {
    if (payload.peopleByMonth && typeof payload.peopleByMonth === 'object') {
      return payload.peopleByMonth;
    }
    if (Array.isArray(payload.peopleState) && payload.peopleState.length > 0) {
      const baseMonth = typeof payload.monthValue === 'string' ? payload.monthValue : '2026-04';
      return { [baseMonth]: payload.peopleState };
    }
    return {};
  }

  private resolveOpsPreviewPeopleForMonth(
    targetMonth: string,
    source: Record<string, OpsPreviewPersonRow[]>
  ): OpsPreviewPersonRow[] {
    if (Array.isArray(source[targetMonth]) && source[targetMonth].length > 0) return source[targetMonth];
    const prevMonth = this.getPrevMonthValue(targetMonth);
    if (prevMonth && Array.isArray(source[prevMonth]) && source[prevMonth].length > 0) return source[prevMonth];
    return [];
  }

  private async resolveKtkVvoTrucksOnLineFromPreview(year: number, month: number, daysInMonth: number): Promise<number[] | null> {
    const row = await this.operationsPreviewRepo.findOne({
      where: { scopeKey: this.operationsPreviewScopeKey },
    });
    if (!row) return null;

    const payload = (row.payload ?? {}) as OpsPreviewPersistedState;
    const overrides = (payload.overrides ?? {}) as Record<OpsPreviewScopeKey, Record<string, OpsPreviewCellCode>>;
    const peopleByMonth = this.extractPeopleByMonth(payload);
    const monthValue = `${year}-${String(month).padStart(2, '0')}`;
    const factScopeKey = `fact|${monthValue}` as OpsPreviewScopeKey;
    const factScope = overrides[factScopeKey] ?? {};
    const monthPeople = this.resolveOpsPreviewPeopleForMonth(monthValue, peopleByMonth).filter(
      (person) => person.department === 'Контейнеры'
    );
    if (monthPeople.length === 0) {
      return Array.from({ length: daysInMonth }, () => 0);
    }

    const totals = Array.from({ length: daysInMonth }, (_, dayIndex) => {
      const day = dayIndex + 1;
      let total = 0;
      for (const person of monthPeople) {
        const lane1 = factScope[`${person.id}-1-${day}`] ?? 'E';
        const lane2 = person.secondName ? factScope[`${person.id}-2-${day}`] ?? 'E' : null;
        const worked = lane1 === 'W' || lane1 === 'H' || lane2 === 'W' || lane2 === 'H';
        if (worked) total += 1;
      }
      return total;
    });

    return totals;
  }

  private async resolveAutoEfficiencyFromPreview(
    year: number,
    month: number,
    daysInMonth: number,
    dayLimit: number
  ): Promise<AutoPreviewEfficiency | null> {
    const row = await this.operationsPreviewRepo.findOne({
      where: { scopeKey: this.operationsPreviewScopeKey },
    });
    if (!row) return null;

    const payload = (row.payload ?? {}) as OpsPreviewPersistedState;
    const overrides = (payload.overrides ?? {}) as Record<OpsPreviewScopeKey, Record<string, OpsPreviewCellCode>>;
    const peopleByMonth = this.extractPeopleByMonth(payload);
    const monthValue = `${year}-${String(month).padStart(2, '0')}`;
    const factScopeKey = `fact|${monthValue}` as OpsPreviewScopeKey;
    const factScope = overrides[factScopeKey] ?? {};
    const monthPeople = this.resolveOpsPreviewPeopleForMonth(monthValue, peopleByMonth).filter(
      (person) => person.department === 'Авто'
    );

    const uniquePlatesCount = new Set(
      monthPeople.map((person) => (person.plate ?? '').trim().toUpperCase()).filter((plate) => plate.length > 0)
    ).size;

    if (uniquePlatesCount === 0) {
      return {
        uniquePlatesCount: 0,
        workAutoDays: 0,
        cargoRemovalDays: 0,
        unloadFactor: 0,
        avgTripDuration: 0,
      };
    }

    let workAutoDays = 0;
    let cargoRemovalDays = 0;

    monthPeople.forEach((person) => {
      for (let day = 1; day <= Math.min(daysInMonth, dayLimit); day += 1) {
        const lane1 = factScope[`${person.id}-1-${day}`] ?? 'E';
        const lane2 = person.secondName ? factScope[`${person.id}-2-${day}`] ?? 'E' : null;
        const dayCodes = [lane1, lane2].filter(Boolean) as OpsPreviewCellCode[];
        if (dayCodes.some((code) => code === 'S')) {
          cargoRemovalDays += 1;
        }
        if (dayCodes.some((code) => code === 'W' || code === 'H' || code === 'S')) {
          workAutoDays += 1;
        }
      }
    });

    return {
      uniquePlatesCount,
      workAutoDays,
      cargoRemovalDays,
      unloadFactor: cargoRemovalDays > 0 ? cargoRemovalDays / uniquePlatesCount : 0,
      avgTripDuration: cargoRemovalDays > 0 ? workAutoDays / cargoRemovalDays : 0,
    };
  }

  async getSegmentReport(params: SegmentReportParams): Promise<{
    segment: { code: PlanningSegmentCode; name: string };
    year: number;
    month: number;
    asOfDate: string;
    daysInMonth: number;
    lastUpdatedAt: string | null;
    gridRows: PlanningGridRow[];
    dashboard: SegmentDashboard;
  }> {
    const segment = await this.segmentRepo.findOne({ where: { code: params.segmentCode } });
    if (!segment) {
      throw new Error('Segment not found');
    }

    const metrics = await this.metricRepo.find({
      where: { segmentId: segment.id },
      order: { orderIndex: 'ASC' },
    });

    const daysInMonth = getDaysInMonth(params.year, params.month);

    const monthStart = new Date(Date.UTC(params.year, params.month - 1, 1));
    const monthEnd = new Date(Date.UTC(params.year, params.month, 0));

    const rawAsOf = params.asOfDate ? parseIsoDate(params.asOfDate) : new Date();
    const asOfDate = new Date(Date.UTC(rawAsOf.getUTCFullYear(), rawAsOf.getUTCMonth(), rawAsOf.getUTCDate()));

    const effectiveAsOf = new Date(
      Math.min(Math.max(asOfDate.getTime(), monthStart.getTime()), monthEnd.getTime())
    );

    let completedDays = clamp(effectiveAsOf.getUTCDate() - 1, 0, daysInMonth);
    if (asOfDate.getTime() <= monthStart.getTime()) {
      completedDays = 0;
    } else if (asOfDate.getTime() >= monthEnd.getTime()) {
      completedDays = daysInMonth;
    }

    const dailyRows = await this.valuesRepo
      .createQueryBuilder('value')
      .where('value.segment_id = :segmentId', { segmentId: segment.id })
      .andWhere('value.date BETWEEN :fromDate AND :toDate', {
        fromDate: toIsoDate(monthStart),
        toDate: toIsoDate(monthEnd),
      })
      .getMany();

    let lastUpdatedAt: string | null = null;
    let lastUpdatedAtMs = -Infinity;
    for (const row of dailyRows) {
      const updatedAtMs = row.updatedAt ? new Date(row.updatedAt).getTime() : NaN;
      if (Number.isFinite(updatedAtMs) && updatedAtMs > lastUpdatedAtMs) {
        lastUpdatedAtMs = updatedAtMs;
        lastUpdatedAt = new Date(updatedAtMs).toISOString();
      }
    }

    const valuesByMetric = new Map<string, Array<number | null>>();
    for (const metric of metrics) {
      valuesByMetric.set(metric.code, Array.from({ length: daysInMonth }, () => null));
    }

    const metricById = new Map(metrics.map((metric) => [metric.id, metric]));
    const metricIdByCode = new Map(metrics.map((metric) => [metric.code, metric.id]));

    for (const row of dailyRows) {
      const metric = metricById.get(row.metricId);
      if (!metric) {
        continue;
      }
      const rowDate = row.date instanceof Date ? row.date : new Date(String(row.date));
      const day = rowDate.getUTCDate();
      const metricValues = valuesByMetric.get(metric.code);
      if (!metricValues || day < 1 || day > daysInMonth) {
        continue;
      }

      metricValues[day - 1] = row.value === null ? null : Number(row.value);
    }

    if (segment.code === PlanningSegmentCode.KTK_VVO && this.isKtkVvoTrucksOnLineAutoFromPreview(params.year, params.month)) {
      const previewTotals = await this.resolveKtkVvoTrucksOnLineFromPreview(params.year, params.month, daysInMonth);
      if (previewTotals) {
        valuesByMetric.set(
          'ktk_vvo_fact_trucks_on_line',
          previewTotals.map((value) => Number(value))
        );
      }
    }

    const monthlyPlan = await this.monthlyPlanRepo.findOne({
      where: {
        segmentId: segment.id,
        year: params.year,
        month: params.month,
      },
      relations: ['planMetrics'],
    });
    const resolvedPlanByCode = await this.resolvePlanByCodeForMonth(
      segment,
      monthlyPlan,
      metricIdByCode,
      params.year,
      params.month
    );

    const autoWaitingStart = segment.code === PlanningSegmentCode.AUTO
      ? await this.resolveAutoWaitingStart(segment.id, metrics, params.year, params.month)
      : undefined;
    const railWaitingStart = segment.code === PlanningSegmentCode.RAIL
      ? await this.resolveRailWaitingStart(segment.id, metrics, params.year, params.month)
      : undefined;
    this.applyFormulaRows(segment.code, valuesByMetric, daysInMonth, monthlyPlan, autoWaitingStart, railWaitingStart);

    const gridRows: PlanningGridRow[] = metrics.map((metric) => {
      const dayValues = valuesByMetric.get(metric.code) ?? [];

      const monthTotal = (() => {
        if (metric.code === 'auto_debt_delta') {
          const debtOverload = lastUntil(valuesByMetric.get('auto_manual_debt_overload') ?? [], dayValues.length);
          const debtCashback = lastUntil(valuesByMetric.get('auto_manual_debt_cashback') ?? [], dayValues.length);
          const debtUnpaid = lastUntil(valuesByMetric.get('auto_debt_unpaid') ?? [], dayValues.length);
          const debtPaidCards = lastUntil(valuesByMetric.get('auto_debt_paid_cards') ?? [], dayValues.length);
          const debtContractorsVvo = lastUntil(valuesByMetric.get('auto_debt_contractors_vvo') ?? [], dayValues.length);
          return debtUnpaid + debtPaidCards - debtOverload - debtCashback - debtContractorsVvo;
        }
        if (
          metric.aggregation === PlanningMetricAggregation.LAST
          || isWaitingMetricCode(metric.code)
          || isKtkGrossMetricCode(metric.code)
        ) {
          return lastUntil(dayValues, dayValues.length);
        }
        return sum(dayValues);
      })();

      return {
        metricCode: metric.code,
        name: metric.name,
        isEditable:
          metric.isEditable
          && !(
            segment.code === PlanningSegmentCode.KTK_VVO
            && metric.code === 'ktk_vvo_fact_trucks_on_line'
            && this.isKtkVvoTrucksOnLineAutoFromPreview(params.year, params.month)
          ),
        aggregation: metric.aggregation,
        dayValues,
        monthTotal,
      };
    });

    const autoPreviewEfficiency = segment.code === PlanningSegmentCode.AUTO
      ? await this.resolveAutoEfficiencyFromPreview(params.year, params.month, daysInMonth, completedDays + 1)
      : null;

    const dashboard = this.computeDashboard({
      segmentCode: segment.code,
      valuesByMetric,
      monthlyPlan,
      resolvedPlanByCode,
      daysInMonth,
      completedDays,
      asOfDate: toIsoDate(effectiveAsOf),
      autoPreviewEfficiency,
    });

    return {
      segment: { code: segment.code, name: segment.name },
      year: params.year,
      month: params.month,
      asOfDate: toIsoDate(effectiveAsOf),
      daysInMonth,
      lastUpdatedAt,
      gridRows,
      dashboard,
    };
  }


  async getSummaryReport(year: number, month: number, asOfDate?: string, detailed: boolean = false): Promise<SummaryRow[]> {
    const segments = await this.segmentRepo.find({ order: { name: 'ASC' } });
    const items: SummaryRow[] = [];

    for (const segment of segments) {
      const report = await this.getSegmentReport({
        segmentCode: segment.code,
        year,
        month,
        asOfDate,
      });

      const planMonth = Number(report.dashboard.planMonth ?? 0);
      const factToDate = Number(report.dashboard.factToDate ?? 0);
      const monthFact = Number(report.dashboard.monthFact ?? 0);

      const shouldAddTopLevel =
        !detailed ||
        (segment.code !== PlanningSegmentCode.AUTO &&
          segment.code !== PlanningSegmentCode.EXTRA &&
          segment.code !== PlanningSegmentCode.RAIL);

      if (shouldAddTopLevel) {
        items.push({
          segmentCode: segment.code,
          segmentName: topLevelSummaryName(segment.code, segment.name),
          planMonth,
          planToDate: Number(report.dashboard.planToDate ?? 0),
          factToDate,
          monthFact,
          completionToDate: pct(factToDate, Number(report.dashboard.planToDate ?? 0)),
          completionMonth: pct(monthFact, planMonth),
        });
      }

      if (!detailed) {
        continue;
      }

      if (segment.code === PlanningSegmentCode.AUTO) {
        const truck = report.dashboard.truck as Record<string, unknown> | undefined;
        const ktk = report.dashboard.ktk as Record<string, unknown> | undefined;
        const truckSent = report.gridRows.find((row) => row.metricCode === 'auto_truck_sent');
        const ktkSent = report.gridRows.find((row) => row.metricCode === 'auto_ktk_sent');
        const curtainSent = report.gridRows.find((row) => row.metricCode === 'auto_curtain_sent');
        const curtainMonthFact = curtainSent?.monthTotal ?? 0;

        items.push({
          segmentCode: segment.code,
          segmentName: 'Автовозы / Шторы',
          parentSegmentCode: segment.code,
          detailCode: 'AUTO_TRUCK_CURTAIN',
          planMonth: Number(truck?.planMonth ?? 0),
          planToDate: Number(truck?.planToDate ?? 0),
          factToDate: Number(truck?.factToDate ?? 0),
          monthFact: (truckSent?.monthTotal ?? 0) + curtainMonthFact,
          completionToDate: Number(truck?.completionToDatePct ?? 0),
          completionMonth: Number(truck?.completionMonthPct ?? 0),
        });
        items.push({
          segmentCode: segment.code,
          segmentName: 'Авто в ктк',
          parentSegmentCode: segment.code,
          detailCode: 'AUTO_KTK',
          planMonth: Number(ktk?.planMonth ?? 0),
          planToDate: Number(ktk?.planToDate ?? 0),
          factToDate: Number(ktk?.factToDate ?? 0),
          monthFact: ktkSent?.monthTotal ?? 0,
          completionToDate: Number(ktk?.completionToDatePct ?? 0),
          completionMonth: Number(ktk?.completionMonthPct ?? 0),
        });
      }

      if (segment.code === PlanningSegmentCode.EXTRA) {
        const detailMetrics = [
          { code: 'extra_groupage', name: 'Доп.услуги • Сборный груз', detailCode: 'EXTRA_GROUPAGE' },
          { code: 'extra_curtains', name: 'Доп.услуги • Шторы (тенты)', detailCode: 'EXTRA_CURTAINS' },
          { code: 'extra_forwarding', name: 'Доп.услуги • Экспедирование', detailCode: 'EXTRA_FORWARDING' },
          { code: 'extra_repack', name: 'Доп.услуги • Перетарки/доукрепление', detailCode: 'EXTRA_REPACK' },
        ];

        for (const metric of detailMetrics) {
          const row = report.gridRows.find((gridRow) => gridRow.metricCode === metric.code);
          items.push({
            segmentCode: segment.code,
            segmentName: metric.name.replace('Доп.услуги • ', '').replace('Перетарки/доукрепление', 'Перетарка/доукрепление'),
            parentSegmentCode: segment.code,
            detailCode: metric.detailCode,
            planMonth: 0,
            planToDate: 0,
            factToDate: report.daysInMonth > 0 ? sumUntil(row?.dayValues ?? [], report.dashboard.completedDays as number) : 0,
            monthFact: row?.monthTotal ?? 0,
            completionToDate: 0,
            completionMonth: 0,
          });
        }
      }

      if (segment.code === PlanningSegmentCode.RAIL) {
        const receivedRow = report.gridRows.find((row) => row.metricCode === 'rail_total_received');
        const waitingRow = report.gridRows.find((row) => row.metricCode === 'rail_total_waiting');
        const dataDays = Math.max(1, Math.min(report.daysInMonth, (report.dashboard.completedDays as number) + 1));

        items.push({
          segmentCode: segment.code,
          segmentName: 'Из/Во Владивосток',
          parentSegmentCode: segment.code,
          detailCode: 'RAIL_TOTAL_FLOW',
          planMonth: Number(report.dashboard.planMonth ?? 0),
          planToDate: Number(report.dashboard.planToDate ?? 0),
          factToDate: Number(report.dashboard.factToDate ?? 0),
          monthFact: Number(report.dashboard.monthFact ?? 0),
          completionToDate: Number(report.dashboard.completionToDatePct ?? 0),
          completionMonth: Number(report.dashboard.completionMonthPct ?? 0),
        });

        if (receivedRow) {
          items.push({
            segmentCode: segment.code,
            segmentName: 'Принято всего',
            parentSegmentCode: segment.code,
            detailCode: 'RAIL_RECEIVED_TOTAL',
            planMonth: 0,
            planToDate: 0,
            factToDate: report.daysInMonth > 0 ? sumUntil(receivedRow.dayValues ?? [], dataDays) : 0,
            monthFact: receivedRow.monthTotal ?? 0,
            completionToDate: 0,
            completionMonth: 0,
          });
        }

        if (waitingRow) {
          items.push({
            segmentCode: segment.code,
            segmentName: 'В ожидании отгрузки всего',
            parentSegmentCode: segment.code,
            detailCode: 'RAIL_WAITING_TOTAL',
            planMonth: 0,
            planToDate: 0,
            factToDate: report.daysInMonth > 0 ? lastUntil(waitingRow.dayValues ?? [], dataDays) : 0,
            monthFact: waitingRow.monthTotal ?? 0,
            completionToDate: 0,
            completionMonth: 0,
          });
        }
      }
    }

    return items;
  }

  private applyFormulaRows(
    segmentCode: PlanningSegmentCode,
    valuesByMetric: Map<string, Array<number | null>>,
    daysInMonth: number,
    monthlyPlan: PlanningMonthlyPlan | null,
    autoWaitingStart?: Record<string, number | undefined>,
    railWaitingStart?: number
  ): void {
    if (segmentCode === PlanningSegmentCode.KTK_VVO) {
      this.fillDailySum(valuesByMetric, 'ktk_vvo_plan_total_per_day', ['ktk_vvo_plan_unload_load', 'ktk_vvo_plan_move'], daysInMonth);
      this.fillDailySum(valuesByMetric, 'ktk_vvo_fact_total_per_day', ['ktk_vvo_fact_unload_load', 'ktk_vvo_fact_move'], daysInMonth);
      return;
    }

    if (segmentCode === PlanningSegmentCode.KTK_MOW) {
      this.fillDailySum(valuesByMetric, 'ktk_mow_plan_total_per_day', ['ktk_mow_plan_unload_load', 'ktk_mow_plan_move'], daysInMonth);
      this.fillDailySum(valuesByMetric, 'ktk_mow_fact_total_per_day', ['ktk_mow_fact_unload_load', 'ktk_mow_fact_move'], daysInMonth);
      return;
    }

    if (segmentCode === PlanningSegmentCode.AUTO) {
      const waitingStart = autoWaitingStart ?? (monthlyPlan?.params?.waitingStart ?? {}) as Record<string, number | undefined>;
      this.fillAutoWaiting(valuesByMetric, daysInMonth, waitingStart);
      this.fillDailySum(valuesByMetric, 'auto_total_received', ['auto_truck_received', 'auto_ktk_received', 'auto_curtain_received'], daysInMonth);
      this.fillDailySum(valuesByMetric, 'auto_total_sent', ['auto_truck_sent', 'auto_ktk_sent', 'auto_curtain_sent'], daysInMonth);
      this.fillDailySum(valuesByMetric, 'auto_total_waiting', ['auto_truck_waiting', 'auto_ktk_waiting', 'auto_curtain_waiting'], daysInMonth);
      this.fillDailyDebtDelta(valuesByMetric, daysInMonth);
      return;
    }

    if (segmentCode === PlanningSegmentCode.RAIL) {
      this.fillDailySum(valuesByMetric, 'rail_from_vvo_total', ['rail_from_vvo_20', 'rail_from_vvo_40'], daysInMonth);
      this.fillDailySum(valuesByMetric, 'rail_to_vvo_total', ['rail_to_vvo_20', 'rail_to_vvo_40'], daysInMonth);
      this.fillDailySum(valuesByMetric, 'rail_total', ['rail_from_vvo_total', 'rail_to_vvo_total'], daysInMonth);
      this.fillRailWaiting(valuesByMetric, daysInMonth, safeNumber(railWaitingStart));
      return;
    }

    if (segmentCode === PlanningSegmentCode.EXTRA) {
      this.fillDailySum(valuesByMetric, 'extra_total', ['extra_groupage', 'extra_curtains', 'extra_forwarding', 'extra_repack'], daysInMonth);
    }
  }

  private fillDailyDebtDelta(valuesByMetric: Map<string, Array<number | null>>, daysInMonth: number): void {
    const overload = valuesByMetric.get('auto_manual_debt_overload') ?? Array.from({ length: daysInMonth }, () => null);
    const cashback = valuesByMetric.get('auto_manual_debt_cashback') ?? Array.from({ length: daysInMonth }, () => null);
    const unpaid = valuesByMetric.get('auto_debt_unpaid') ?? Array.from({ length: daysInMonth }, () => null);
    const paidCards = valuesByMetric.get('auto_debt_paid_cards') ?? Array.from({ length: daysInMonth }, () => null);
    const contractors = valuesByMetric.get('auto_debt_contractors_vvo') ?? Array.from({ length: daysInMonth }, () => null);

    const delta = Array.from({ length: daysInMonth }, (_, idx) => {
      const aRaw = unpaid[idx];
      const bRaw = paidCards[idx];
      const cRaw = overload[idx];
      const dRaw = cashback[idx];
      const eRaw = contractors[idx];
      if (aRaw === null && bRaw === null && cRaw === null && dRaw === null && eRaw === null) {
        return null;
      }
      const a = safeNumber(aRaw);
      const b = safeNumber(bRaw);
      const c = safeNumber(cRaw);
      const d = safeNumber(dRaw);
      const e = safeNumber(eRaw);
      return a + b - c - d - e;
    });

    valuesByMetric.set('auto_debt_delta', delta);
  }

  private async resolveAutoWaitingStart(
    segmentId: string,
    metrics: PlanningMetric[],
    year: number,
    month: number,
    depth = 0
  ): Promise<Record<string, number | undefined>> {
    if (depth > 36) {
      return { truck: 0, ktk: 0, curtain: 0 };
    }

    const prevMonth = month === 1 ? 12 : month - 1;
    const prevYear = month === 1 ? year - 1 : year;
    const prevDaysInMonth = getDaysInMonth(prevYear, prevMonth);
    const prevStartDate = new Date(Date.UTC(prevYear, prevMonth - 1, 1));
    const prevEndDate = new Date(Date.UTC(prevYear, prevMonth - 1, prevDaysInMonth));

    const prevRows = await this.valuesRepo
      .createQueryBuilder('value')
      .where('value.segment_id = :segmentId', { segmentId })
      .andWhere('value.date BETWEEN :fromDate AND :toDate', {
        fromDate: toIsoDate(prevStartDate),
        toDate: toIsoDate(prevEndDate),
      })
      .getMany();

    if (prevRows.length === 0) {
      // Если предыдущий месяц пустой, берем остаток из более раннего месяца (без обнуления на границе года).
      return this.resolveAutoWaitingStart(segmentId, metrics, prevYear, prevMonth, depth + 1);
    }

    // Важное правило: старт текущего месяца = финальное ожидание прошлого месяца.
    // Не прибавляем "seed/start" повторно, чтобы не удваивать перенос.
    const prevStart = await this.resolveAutoWaitingStart(
      segmentId,
      metrics,
      prevYear,
      prevMonth,
      depth + 1
    );

    const metricById = new Map(metrics.map((metric) => [metric.id, metric.code]));
    const valuesByCode = new Map<string, Array<number | null>>();
    [
      'auto_truck_received',
      'auto_truck_sent',
      'auto_ktk_received',
      'auto_ktk_sent',
      'auto_curtain_received',
      'auto_curtain_sent',
    ].forEach((code) => valuesByCode.set(code, Array.from({ length: prevDaysInMonth }, () => null)));

    for (const row of prevRows) {
      const code = metricById.get(row.metricId);
      if (!code || !valuesByCode.has(code)) {
        continue;
      }
      const rowDate = row.date instanceof Date ? row.date : new Date(String(row.date));
      const day = rowDate.getUTCDate();
      if (day < 1 || day > prevDaysInMonth) {
        continue;
      }
      valuesByCode.get(code)![day - 1] = row.value === null ? null : Number(row.value);
    }

    const calcWaitingEnd = (
      start: number | undefined,
      received: Array<number | null>,
      sent: Array<number | null>
    ): number => {
      let carry = safeNumber(start);
      for (let i = 0; i < prevDaysInMonth; i += 1) {
        carry = carry + safeNumber(received[i]) - safeNumber(sent[i]);
      }
      return carry;
    };

    return {
      truck: calcWaitingEnd(prevStart.truck, valuesByCode.get('auto_truck_received') ?? [], valuesByCode.get('auto_truck_sent') ?? []),
      ktk: calcWaitingEnd(prevStart.ktk, valuesByCode.get('auto_ktk_received') ?? [], valuesByCode.get('auto_ktk_sent') ?? []),
      curtain: calcWaitingEnd(prevStart.curtain, valuesByCode.get('auto_curtain_received') ?? [], valuesByCode.get('auto_curtain_sent') ?? []),
    };
  }

  private async resolveRailWaitingStart(
    segmentId: string,
    metrics: PlanningMetric[],
    year: number,
    month: number,
    depth = 0
  ): Promise<number> {
    if (depth > 36) {
      return 0;
    }

    const prevMonth = month === 1 ? 12 : month - 1;
    const prevYear = month === 1 ? year - 1 : year;
    const prevDaysInMonth = getDaysInMonth(prevYear, prevMonth);
    const prevStartDate = new Date(Date.UTC(prevYear, prevMonth - 1, 1));
    const prevEndDate = new Date(Date.UTC(prevYear, prevMonth - 1, prevDaysInMonth));

    const prevRows = await this.valuesRepo
      .createQueryBuilder('value')
      .where('value.segment_id = :segmentId', { segmentId })
      .andWhere('value.date BETWEEN :fromDate AND :toDate', {
        fromDate: toIsoDate(prevStartDate),
        toDate: toIsoDate(prevEndDate),
      })
      .getMany();

    if (prevRows.length === 0) {
      return this.resolveRailWaitingStart(segmentId, metrics, prevYear, prevMonth, depth + 1);
    }

    const prevStart = await this.resolveRailWaitingStart(
      segmentId,
      metrics,
      prevYear,
      prevMonth,
      depth + 1
    );

    const metricById = new Map(metrics.map((metric) => [metric.id, metric.code]));
    const valuesByCode = new Map<string, Array<number | null>>();
    [
      'rail_total_received',
      'rail_from_vvo_20',
      'rail_from_vvo_40',
      'rail_to_vvo_20',
      'rail_to_vvo_40',
      'rail_from_vvo_total',
      'rail_to_vvo_total',
      'rail_total',
      'rail_total_waiting',
    ].forEach((code) => valuesByCode.set(code, Array.from({ length: prevDaysInMonth }, () => null)));

    for (const row of prevRows) {
      const code = metricById.get(row.metricId);
      if (!code || !valuesByCode.has(code)) {
        continue;
      }
      const rowDate = row.date instanceof Date ? row.date : new Date(String(row.date));
      const day = rowDate.getUTCDate();
      const metricValues = valuesByCode.get(code);
      if (!metricValues || day < 1 || day > prevDaysInMonth) {
        continue;
      }
      metricValues[day - 1] = row.value === null ? null : Number(row.value);
    }

    this.fillDailySum(valuesByCode, 'rail_from_vvo_total', ['rail_from_vvo_20', 'rail_from_vvo_40'], prevDaysInMonth);
    this.fillDailySum(valuesByCode, 'rail_to_vvo_total', ['rail_to_vvo_20', 'rail_to_vvo_40'], prevDaysInMonth);
    this.fillDailySum(valuesByCode, 'rail_total', ['rail_from_vvo_total', 'rail_to_vvo_total'], prevDaysInMonth);
    this.fillRailWaiting(valuesByCode, prevDaysInMonth, prevStart);

    const waiting = valuesByCode.get('rail_total_waiting') ?? [];
    return lastUntil(waiting, waiting.length);
  }

  private fillDailySum(
    valuesByMetric: Map<string, Array<number | null>>,
    targetMetric: string,
    sourceMetrics: string[],
    daysInMonth: number
  ): void {
    const target = valuesByMetric.get(targetMetric);
    if (!target) {
      return;
    }

    for (let day = 0; day < daysInMonth; day += 1) {
      let result = 0;
      for (const source of sourceMetrics) {
        const sourceValues = valuesByMetric.get(source);
        result += safeNumber(sourceValues?.[day]);
      }
      target[day] = result;
    }
  }

  private fillAutoWaiting(
    valuesByMetric: Map<string, Array<number | null>>,
    daysInMonth: number,
    waitingStart: Record<string, number | undefined>
  ): void {
    const configs = [
      {
        received: 'auto_truck_received',
        sent: 'auto_truck_sent',
        waiting: 'auto_truck_waiting',
        start: safeNumber(waitingStart.truck),
      },
      {
        received: 'auto_ktk_received',
        sent: 'auto_ktk_sent',
        waiting: 'auto_ktk_waiting',
        start: safeNumber(waitingStart.ktk),
      },
      {
        received: 'auto_curtain_received',
        sent: 'auto_curtain_sent',
        waiting: 'auto_curtain_waiting',
        start: safeNumber(waitingStart.curtain),
      },
    ];

    for (const cfg of configs) {
      const received = valuesByMetric.get(cfg.received) ?? Array.from({ length: daysInMonth }, () => 0);
      const sent = valuesByMetric.get(cfg.sent) ?? Array.from({ length: daysInMonth }, () => 0);
      const waiting = valuesByMetric.get(cfg.waiting);

      if (!waiting) {
        continue;
      }

      let carry = cfg.start;
      for (let day = 0; day < daysInMonth; day += 1) {
        carry = carry + safeNumber(received[day]) - safeNumber(sent[day]);
        waiting[day] = carry;
      }
    }
  }

  private fillRailWaiting(
    valuesByMetric: Map<string, Array<number | null>>,
    daysInMonth: number,
    waitingStart: number
  ): void {
    const received = valuesByMetric.get('rail_total_received') ?? Array.from({ length: daysInMonth }, () => 0);
    const sent = valuesByMetric.get('rail_total') ?? Array.from({ length: daysInMonth }, () => 0);
    const waiting = valuesByMetric.get('rail_total_waiting');

    if (!waiting) {
      return;
    }

    let carry = safeNumber(waitingStart);
    for (let day = 0; day < daysInMonth; day += 1) {
      carry = carry + safeNumber(received[day]) - safeNumber(sent[day]);
      waiting[day] = carry;
    }
  }

  private computeDashboard(params: {
    segmentCode: PlanningSegmentCode;
    valuesByMetric: Map<string, Array<number | null>>;
    monthlyPlan: PlanningMonthlyPlan | null;
    resolvedPlanByCode: Map<PlanningPlanMetricCode, number>;
    daysInMonth: number;
    completedDays: number;
    asOfDate: string;
    autoPreviewEfficiency: AutoPreviewEfficiency | null;
  }): SegmentDashboard {
    const { segmentCode, valuesByMetric, monthlyPlan, resolvedPlanByCode, daysInMonth, completedDays, asOfDate, autoPreviewEfficiency } = params;
    const dataDays = Math.max(1, Math.min(daysInMonth, completedDays + 1));

    const planMetricMap = new Map<PlanningPlanMetricCode, PlanningMonthlyPlanMetric>();
    for (const metric of monthlyPlan?.planMetrics ?? []) {
      planMetricMap.set(metric.code, metric);
    }

    const base: DashboardBase = {
      asOfDate,
      daysInMonth,
      completedDays,
    };

    if (segmentCode === PlanningSegmentCode.KTK_VVO || segmentCode === PlanningSegmentCode.KTK_MOW) {
      const isVvo = segmentCode === PlanningSegmentCode.KTK_VVO;
      const prefix = isVvo ? 'ktk_vvo' : 'ktk_mow';
      const total = valuesByMetric.get(`${prefix}_fact_total_per_day`) ?? [];
      const gross = valuesByMetric.get(`${prefix}_manual_gross`) ?? [];
      const trucks = valuesByMetric.get(`${prefix}_fact_trucks_on_line`) ?? [];

      const planMonth = resolvedPlanByCode.get(PlanningPlanMetricCode.KTK_PLAN_REQUESTS)
        ?? getPlanValue(planMetricMap, PlanningPlanMetricCode.KTK_PLAN_REQUESTS);
      const planToDate = calcPlanToDate(planMonth, daysInMonth, completedDays);
      const factToDate = sumUntil(total, dataDays);
      const monthFact = sum(total);
      const grossToDate = lastUntil(gross, dataDays);
      const avgRequestCost = factToDate > 0 ? grossToDate / factToDate : 0;

      return {
        ...base,
        planMonth,
        planToDate,
        factToDate,
        monthFact,
        completionMonthPct: pct(monthFact, planMonth),
        completionToDatePct: pct(factToDate, planToDate),
        avgPerDay: dataDays > 0 ? factToDate / dataDays : 0,
        grossTotal: grossToDate,
        grossAvgPerDay: dataDays > 0 ? grossToDate / dataDays : 0,
        avgRequestCost,
        trucksAvgOnLine: avgUntil(trucks, dataDays),
      };
    }

    if (segmentCode === PlanningSegmentCode.AUTO) {
      const planTruckMonth = resolvedPlanByCode.get(PlanningPlanMetricCode.AUTO_PLAN_TRUCK)
        ?? getPlanValue(planMetricMap, PlanningPlanMetricCode.AUTO_PLAN_TRUCK);
      const planKtkMonth = resolvedPlanByCode.get(PlanningPlanMetricCode.AUTO_PLAN_KTK)
        ?? getPlanValue(planMetricMap, PlanningPlanMetricCode.AUTO_PLAN_KTK);

      const planTruckToDate = calcPlanToDate(planTruckMonth, daysInMonth, completedDays);
      const planKtkToDate = calcPlanToDate(planKtkMonth, daysInMonth, completedDays);

      const truckSent = valuesByMetric.get('auto_truck_sent') ?? [];
      const curtainSent = valuesByMetric.get('auto_curtain_sent') ?? [];
      const ktkSent = valuesByMetric.get('auto_ktk_sent') ?? [];

      // "Автовозы" в отчете = Автовоз + Штора
      const truckFactToDate = sumUntil(truckSent, dataDays) + sumUntil(curtainSent, dataDays);
      const ktkFactToDate = sumUntil(ktkSent, dataDays);

      const waitingTotal = lastUntil(valuesByMetric.get('auto_total_waiting') ?? [], dataDays);
      const waitingTruck = lastUntil(valuesByMetric.get('auto_truck_waiting') ?? [], dataDays);
      const waitingKtk = lastUntil(valuesByMetric.get('auto_ktk_waiting') ?? [], dataDays);
      const waitingCurtain = lastUntil(valuesByMetric.get('auto_curtain_waiting') ?? [], dataDays);

      const debtOverload = lastUntil(valuesByMetric.get('auto_manual_debt_overload') ?? [], dataDays);
      const debtCashback = lastUntil(valuesByMetric.get('auto_manual_debt_cashback') ?? [], dataDays);
      const debtUnpaid = lastUntil(valuesByMetric.get('auto_debt_unpaid') ?? [], dataDays);
      const debtPaidCards = lastUntil(valuesByMetric.get('auto_debt_paid_cards') ?? [], dataDays);
      const debtContractorsVvo = lastUntil(valuesByMetric.get('auto_debt_contractors_vvo') ?? [], dataDays);
      const debtDelta = debtUnpaid + debtPaidCards - debtOverload - debtCashback - debtContractorsVvo;

      const factToDate = truckFactToDate + ktkFactToDate;
      const planMonth = planTruckMonth + planKtkMonth;
      const planToDate = planTruckToDate + planKtkToDate;
      const monthFact = sum(truckSent) + sum(curtainSent) + sum(ktkSent);

      return {
        ...base,
        planMonth,
        planToDate,
        factToDate,
        monthFact,
        completionMonthPct: pct(monthFact, planMonth),
        completionToDatePct: pct(factToDate, planToDate),
        avgPerDay: dataDays > 0 ? factToDate / dataDays : 0,
        truck: {
          planMonth: planTruckMonth,
          planToDate: planTruckToDate,
          factToDate: truckFactToDate,
          completionMonthPct: pct(sum(truckSent) + sum(curtainSent), planTruckMonth),
          completionToDatePct: pct(truckFactToDate, planTruckToDate),
          avgPerDay: dataDays > 0 ? truckFactToDate / dataDays : 0,
          unloadFactor: Number(autoPreviewEfficiency?.unloadFactor ?? 0),
          avgTripDuration: Number(autoPreviewEfficiency?.avgTripDuration ?? 0),
        },
        ktk: {
          planMonth: planKtkMonth,
          planToDate: planKtkToDate,
          factToDate: ktkFactToDate,
          completionMonthPct: pct(sum(ktkSent), planKtkMonth),
          completionToDatePct: pct(ktkFactToDate, planKtkToDate),
          avgPerDay: dataDays > 0 ? ktkFactToDate / dataDays : 0,
        },
        waitingTotal,
        waitingTruck,
        waitingKtk,
        waitingCurtain,
        debtOverload,
        debtCashback,
        debtUnpaid,
        debtPaidCards,
        debtContractorsVvo,
        debtDelta,
      };
    }

    if (segmentCode === PlanningSegmentCode.RAIL) {
      const planMonth = resolvedPlanByCode.get(PlanningPlanMetricCode.RAIL_PLAN_KTK)
        ?? getPlanValue(planMetricMap, PlanningPlanMetricCode.RAIL_PLAN_KTK);
      const planToDate = calcPlanToDate(planMonth, daysInMonth, completedDays);
      const railTotal = valuesByMetric.get('rail_total') ?? [];
      const railWaiting = valuesByMetric.get('rail_total_waiting') ?? [];
      const factToDate = sumUntil(railTotal, dataDays);
      const monthFact = sum(railTotal);
      const waitingTotal = lastUntil(railWaiting, dataDays);

      return {
        ...base,
        planMonth,
        planToDate,
        factToDate,
        monthFact,
        waitingTotal,
        completionMonthPct: pct(monthFact, planMonth),
        completionToDatePct: pct(factToDate, planToDate),
        avgPerDay: dataDays > 0 ? factToDate / dataDays : 0,
      };
    }

    if (segmentCode === PlanningSegmentCode.TO) {
      const planMonth = resolvedPlanByCode.get(PlanningPlanMetricCode.TO_PLAN)
        ?? getPlanValue(planMetricMap, PlanningPlanMetricCode.TO_PLAN);
      const planToDate = calcPlanToDate(planMonth, daysInMonth, completedDays);
      const values = valuesByMetric.get('to_count') ?? [];
      const factToDate = sumUntil(values, dataDays);
      const monthFact = sum(values);

      return {
        ...base,
        planMonth,
        planToDate,
        factToDate,
        monthFact,
        completionMonthPct: pct(monthFact, planMonth),
        completionToDatePct: pct(factToDate, planToDate),
        avgPerDay: dataDays > 0 ? factToDate / dataDays : 0,
      };
    }

    if (segmentCode === PlanningSegmentCode.EXTRA) {
      const total = valuesByMetric.get('extra_total') ?? [];
      const factToDate = sumUntil(total, dataDays);
      const monthFact = sum(total);

      return {
        ...base,
        planMonth: 0,
        planToDate: 0,
        factToDate,
        monthFact,
        completionMonthPct: 0,
        completionToDatePct: 0,
        avgPerDay: dataDays > 0 ? factToDate / dataDays : 0,
        groupage: sumUntil(valuesByMetric.get('extra_groupage') ?? [], dataDays),
        curtains: sumUntil(valuesByMetric.get('extra_curtains') ?? [], dataDays),
        forwarding: sumUntil(valuesByMetric.get('extra_forwarding') ?? [], dataDays),
        repack: sumUntil(valuesByMetric.get('extra_repack') ?? [], dataDays),
      };
    }

    return {
      ...base,
      planMonth: 0,
      planToDate: 0,
      factToDate: 0,
      monthFact: 0,
      completionMonthPct: 0,
      completionToDatePct: 0,
      avgPerDay: 0,
    };
  }

  private async resolvePlanByCodeForMonth(
    segment: PlanningSegment,
    monthlyPlan: PlanningMonthlyPlan | null,
    metricIdByCode: Map<string, string>,
    year: number,
    month: number
  ): Promise<Map<PlanningPlanMetricCode, number>> {
    const resolved = new Map<PlanningPlanMetricCode, number>();
    const currentMap = new Map<PlanningPlanMetricCode, PlanningMonthlyPlanMetric>();
    for (const metric of monthlyPlan?.planMetrics ?? []) {
      currentMap.set(metric.code, metric);
    }

    const yearPlans = await this.monthlyPlanRepo.find({
      where: { segmentId: segment.id, year },
      relations: ['planMetrics'],
    });
    const yearPlanByMonth = new Map<number, PlanningMonthlyPlan>();
    for (const plan of yearPlans) {
      yearPlanByMonth.set(plan.month, plan);
    }

    for (const [code, currentMetric] of currentMap.entries()) {
      let debt = 0;
      let carryForRequestedMonth = 0;

      for (let currentMonth = 1; currentMonth <= month; currentMonth += 1) {
        const monthPlan = yearPlanByMonth.get(currentMonth);
        const monthMetric = monthPlan?.planMetrics?.find((item) => item.code === code);
        const base = safeNumber(monthMetric?.basePlan ?? (currentMonth === month ? currentMetric.basePlan : 0));
        const carry = base + debt;

        const fact = await this.getFactForPlanMetric(
          segment.id,
          segment.code,
          code,
          metricIdByCode,
          year,
          currentMonth
        );
        debt = Math.max(0, carry - fact);
        carryForRequestedMonth = carry;
      }

      resolved.set(code, carryForRequestedMonth);
    }

    return resolved;
  }

  private async getFactForPlanMetric(
    segmentId: string,
    segmentCode: PlanningSegmentCode,
    planMetricCode: PlanningPlanMetricCode,
    metricIdByCode: Map<string, string>,
    year: number,
    month: number
  ): Promise<number> {
    const factMetricCodes = (() => {
      if (segmentCode === PlanningSegmentCode.KTK_VVO) {
        return ['ktk_vvo_fact_unload_load', 'ktk_vvo_fact_move'];
      }
      if (segmentCode === PlanningSegmentCode.KTK_MOW) {
        return ['ktk_mow_fact_unload_load', 'ktk_mow_fact_move'];
      }
      if (segmentCode === PlanningSegmentCode.AUTO) {
        if (planMetricCode === PlanningPlanMetricCode.AUTO_PLAN_TRUCK) {
          return ['auto_truck_sent', 'auto_curtain_sent'];
        }
        if (planMetricCode === PlanningPlanMetricCode.AUTO_PLAN_KTK) {
          return ['auto_ktk_sent'];
        }
      }
      if (segmentCode === PlanningSegmentCode.RAIL) {
        return ['rail_from_vvo_20', 'rail_from_vvo_40', 'rail_to_vvo_20', 'rail_to_vvo_40'];
      }
      if (segmentCode === PlanningSegmentCode.TO) {
        return ['to_count'];
      }
      return [];
    })();

    const metricIds = factMetricCodes
      .map((code) => metricIdByCode.get(code))
      .filter((value): value is string => Boolean(value));
    if (!metricIds.length) {
      return 0;
    }

    const monthStart = new Date(Date.UTC(year, month - 1, 1));
    const monthEnd = new Date(Date.UTC(year, month, 0));
    const row = await this.valuesRepo
      .createQueryBuilder('value')
      .select('COALESCE(SUM(value.value), 0)', 'total')
      .where('value.segment_id = :segmentId', { segmentId })
      .andWhere('value.metric_id IN (:...metricIds)', { metricIds })
      .andWhere('value.date BETWEEN :fromDate AND :toDate', {
        fromDate: toIsoDate(monthStart),
        toDate: toIsoDate(monthEnd),
      })
      .getRawOne<{ total: string }>();

    return Number(row?.total ?? 0);
  }
}

export const planningV2ReportService = new PlanningV2ReportService();
