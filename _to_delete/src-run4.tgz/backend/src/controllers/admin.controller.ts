import { Request, Response, NextFunction } from 'express';
import { AppDataSource } from '../config/data-source';
import { User } from '../models/user.model';
import { AppSetting } from '../models/app-setting.model';
import { AuditLog } from '../models/audit-log.model';
import { Report } from '../models/reports.model';
import { ContractWorkSchedule } from '../models/contract-work-schedule.model';
import { WarehouseClient } from '../models/warehouse-client.model';
import { ContractTemplateType } from '../models/contract-template-version.model';
import { logger } from '../utils/logger';
import { sendInvitationEmail } from '../services/email.service';
import { planWebSocketService } from '../services/websocket.service';
import { recordAuditLog } from '../services/audit-log.service';
import { getWarehouseContractState } from '../utils/warehouse-contract';
import {
  CONTRACT_TEMPLATE_LABELS,
  activateContractTemplateVersion,
  createContractTemplateVersion,
  decodeTemplateBase64,
  listContractTemplateVersions,
} from '../services/contract-template.service';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { Between, IsNull, LessThanOrEqual, MoreThanOrEqual, QueryFailedError } from 'typeorm';

const userRepository = AppDataSource.getRepository(User);
const appSettingRepository = AppDataSource.getRepository(AppSetting);
const auditLogRepository = AppDataSource.getRepository(AuditLog);
const reportRepository = AppDataSource.getRepository(Report);
const workScheduleRepository = AppDataSource.getRepository(ContractWorkSchedule);
const warehouseClientRepository = AppDataSource.getRepository(WarehouseClient);

const serializeWarehouseClient = (client: WarehouseClient | null | undefined) => {
  if (!client) return null;
  return {
    id: client.id,
    nameFull: client.counterparty?.nameFull ?? null,
    nameShort: client.counterparty?.nameShort ?? null,
    inn: client.counterparty?.inn ?? null,
    contractNumber: client.contractNumber,
    contractDate: client.contractDate,
    contractEndDate: client.contractEndDate,
    ...getWarehouseContractState(client.contractEndDate),
    isActive: client.isActive,
  };
};

const serializeContractTemplateVersion = (item: Awaited<ReturnType<typeof listContractTemplateVersions>>[number]) => ({
  id: item.id,
  templateType: item.templateType,
  templateLabel: CONTRACT_TEMPLATE_LABELS[item.templateType],
  version: item.version,
  originalName: item.originalName,
  sizeBytes: item.sizeBytes,
  contentSha256: item.contentSha256,
  placeholders: item.placeholders ?? [],
  isActive: item.isActive,
  uploadedByUserId: item.uploadedByUserId,
  createdAt: item.createdAt,
});

const resolveWarehouseClientId = async (
  role: string,
  warehouseClientId: unknown,
): Promise<string | null> => {
  if (role !== 'counterparty_user') return null;
  const normalized = String(warehouseClientId ?? '').trim();
  if (!normalized) {
    const error: any = new Error('Для представителя контрагента выберите клиента склада');
    error.statusCode = 400;
    throw error;
  }
  const client = await warehouseClientRepository.findOne({
    where: { id: normalized, isActive: true },
  });
  if (!client) {
    const error: any = new Error('Активный клиент склада не найден');
    error.statusCode = 400;
    throw error;
  }
  return client.id;
};

export const getUsers = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { role } = req.query;
    const where: any = {};
    if (role) where.role = role;

    const users = await userRepository.find({
      where,
      relations: { warehouseClient: { counterparty: true } },
      order: { createdAt: 'DESC' },
    });

    // Remove password hash from response
    const safeUsers = users.map(user => ({
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      department: user.role, // for backward compatibility
      role: user.role,
      isActive: user.isActive,
      timezone: user.timezone,
      workdayStart: user.workdayStart,
      workdayEnd: user.workdayEnd,
      workdays: user.workdays,
      warehouseClientId: user.warehouseClientId,
      warehouseClient: serializeWarehouseClient(user.warehouseClient),
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    }));

    res.json(safeUsers);
  } catch (error) {
    next(error);
  }
};

export const inviteUser = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { email, fullName, role, warehouseClientId } = req.body;

    const existingUser = await userRepository.findOne({ where: { email } });
    if (existingUser) {
      const error: any = new Error('User already exists');
      error.statusCode = 409;
      throw error;
    }

    // Generate temporary password
    const temporaryPassword = crypto.randomBytes(8).toString('base64url');
    const hashedPassword = await bcrypt.hash(temporaryPassword, 12);

    const user = userRepository.create({
      email,
      passwordHash: hashedPassword,
      fullName,
      role,
      warehouseClientId: await resolveWarehouseClientId(role, warehouseClientId),
      isActive: true,
    });

    await userRepository.save(user);

    let emailSent = true;
    try {
      await sendInvitationEmail(email, fullName, role, temporaryPassword);
    } catch (emailError) {
      emailSent = false;
      logger.warn(`Invitation email failed for ${email}: ${emailError instanceof Error ? emailError.message : emailError}`);
    }

    await recordAuditLog({
      action: 'USER_INVITED',
      userId: req.user?.id,
      entityType: 'user',
      entityId: user.id,
      details: {
        email,
        role,
        warehouseClientId: user.warehouseClientId,
        emailSent,
      },
      req,
    });

    logger.info(`User invited: ${email} (${role})`);

    res.status(201).json({
      message: 'User invited successfully',
      userId: user.id,
      emailSent,
      temporaryPassword: emailSent ? undefined : temporaryPassword,
    });
  } catch (error) {
    if (error instanceof QueryFailedError && (error as any).code === '23505') {
      const duplicateError: any = new Error('Пользователь с таким email уже существует');
      duplicateError.statusCode = 409;
      return next(duplicateError);
    }
    next(error);
  }
};

export const updateUser = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const {
      email,
      fullName,
      role,
      isActive,
      timezone,
      workdayStart,
      workdayEnd,
      workdays,
      warehouseClientId,
    } = req.body;

    const user = await userRepository.findOne({ where: { id } });
    if (!user) {
      const error: any = new Error('User not found');
      error.statusCode = 404;
      throw error;
    }

    if (typeof email === 'string' && email.trim()) {
      user.email = email.trim().toLowerCase();
    }
    if (fullName) user.fullName = fullName;
    if (role) user.role = role;
    if (role !== undefined || warehouseClientId !== undefined) {
      user.warehouseClientId = await resolveWarehouseClientId(
        role || user.role,
        warehouseClientId !== undefined ? warehouseClientId : user.warehouseClientId,
      );
    }
    if (typeof isActive === 'boolean') user.isActive = isActive;
    if (typeof timezone === 'string') user.timezone = timezone.trim() || null;
    if (typeof workdayStart === 'string') user.workdayStart = workdayStart.trim() || null;
    if (typeof workdayEnd === 'string') user.workdayEnd = workdayEnd.trim() || null;
    if (typeof workdays === 'string') user.workdays = workdays.trim() || null;

    await userRepository.save(user);
    const linkedWarehouseClient = user.warehouseClientId
      ? await warehouseClientRepository.findOne({
        where: { id: user.warehouseClientId },
        relations: { counterparty: true },
      })
      : null;

    await recordAuditLog({
      action: 'USER_UPDATED',
      userId: req.user?.id,
      entityType: 'user',
      entityId: user.id,
      details: {
        email: user.email,
        role: user.role,
        isActive: user.isActive,
        warehouseClientId: user.warehouseClientId,
        warehouseClient: serializeWarehouseClient(linkedWarehouseClient),
      },
      req,
    });

    logger.info(`User updated: ${id}`);

    res.json({
      message: 'User updated',
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        department: user.role, // for backward compatibility
        role: user.role,
        isActive: user.isActive,
        timezone: user.timezone,
        workdayStart: user.workdayStart,
        workdayEnd: user.workdayEnd,
        workdays: user.workdays,
        warehouseClientId: user.warehouseClientId,
        warehouseClient: serializeWarehouseClient(linkedWarehouseClient),
      },
    });
  } catch (error) {
    if (error instanceof QueryFailedError && (error as any).code === '23505') {
      const duplicateError: any = new Error('Пользователь с таким email уже существует');
      duplicateError.statusCode = 409;
      return next(duplicateError);
    }
    next(error);
  }
};

export const getContractWorkSchedules = async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const rows = await workScheduleRepository.find({
      order: { scope: 'ASC', roleCode: 'ASC', userId: 'ASC', createdAt: 'ASC' },
    });
    res.json(rows);
  } catch (error) {
    next(error);
  }
};

export const upsertContractWorkSchedules = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const rows = Array.isArray(req.body?.items) ? req.body.items : [];
    for (const item of rows) {
      const scope = String(item?.scope || '').trim() as 'global' | 'role' | 'user';
      if (!['global', 'role', 'user'].includes(scope)) continue;
      const roleCode = scope === 'role' ? String(item?.roleCode || '').trim() || null : null;
      const userId = scope === 'user' ? String(item?.userId || '').trim() || null : null;
      const timezone = String(item?.timezone || '').trim() || 'Asia/Vladivostok';
      const workdayStart = String(item?.workdayStart || '').trim() || '09:00';
      const workdayEnd = String(item?.workdayEnd || '').trim() || '18:00';
      const workdays = Array.isArray(item?.workdays)
        ? item.workdays.map((d: any) => Number(d)).filter((d: number) => Number.isInteger(d) && d >= 0 && d <= 6)
        : [1, 2, 3, 4, 5];
      const isActive = typeof item?.isActive === 'boolean' ? item.isActive : true;

      const existing = await workScheduleRepository.findOne({
        where: {
          scope,
          roleCode: roleCode === null ? IsNull() : roleCode,
          userId: userId === null ? IsNull() : userId,
        },
      });
      if (existing) {
        existing.timezone = timezone;
        existing.workdayStart = workdayStart;
        existing.workdayEnd = workdayEnd;
        existing.workdays = workdays.join(',');
        existing.isActive = isActive;
        await workScheduleRepository.save(existing);
      } else {
        await workScheduleRepository.save(workScheduleRepository.create({
          scope,
          roleCode,
          userId,
          timezone,
          workdayStart,
          workdayEnd,
          workdays: workdays.join(','),
          isActive,
        }));
      }
    }
    const result = await workScheduleRepository.find({
      order: { scope: 'ASC', roleCode: 'ASC', userId: 'ASC', createdAt: 'ASC' },
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
};

export const getContractTemplateVersions = async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const rows = await listContractTemplateVersions();
    res.json(rows.map(serializeContractTemplateVersion));
  } catch (error) {
    next(error);
  }
};

export const uploadContractTemplateVersion = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const templateType = String(req.body?.templateType || '').trim() as ContractTemplateType;
    if (!Object.values(ContractTemplateType).includes(templateType)) {
      const error: any = new Error('Некорректный тип шаблона');
      error.statusCode = 400;
      throw error;
    }

    const originalName = String(req.body?.originalName || '').trim();
    const buffer = decodeTemplateBase64(String(req.body?.contentBase64 || ''));
    const created = await createContractTemplateVersion({
      templateType,
      originalName,
      buffer,
      uploadedByUserId: req.user?.id ?? null,
    });

    await recordAuditLog({
      action: 'CONTRACT_TEMPLATE_UPLOADED',
      userId: req.user?.id,
      entityType: 'contract_template_version',
      entityId: created.id,
      details: {
        templateType,
        version: created.version,
        originalName,
      },
      req,
    });

    res.status(201).json(serializeContractTemplateVersion(created));
  } catch (error) {
    next(error);
  }
};

export const activateContractTemplate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const activated = await activateContractTemplateVersion(req.params.id);
    await recordAuditLog({
      action: 'CONTRACT_TEMPLATE_ACTIVATED',
      userId: req.user?.id,
      entityType: 'contract_template_version',
      entityId: activated.id,
      details: {
        templateType: activated.templateType,
        version: activated.version,
      },
      req,
    });
    res.json(serializeContractTemplateVersion(activated));
  } catch (error) {
    next(error);
  }
};

export const reassignAndDeleteUser = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const targetUserIdRaw = (req.body?.targetUserId ?? req.body?.target_user_id ?? '').toString().trim();
    const targetUserId = targetUserIdRaw;

    if (!targetUserId || targetUserId === id) {
      const error: any = new Error('Укажите корректного целевого пользователя');
      error.statusCode = 400;
      throw error;
    }

    const [sourceUser, targetUser] = await Promise.all([
      userRepository.findOne({ where: { id } }),
      userRepository.findOne({ where: { id: targetUserId } }),
    ]);

    if (!sourceUser) {
      const error: any = new Error('User not found');
      error.statusCode = 404;
      throw error;
    }
    if (!targetUser) {
      const error: any = new Error('Target user not found');
      error.statusCode = 404;
      throw error;
    }

    await AppDataSource.transaction(async (manager) => {
      const reassignMap = [
        { table: 'planning_daily_values', column: 'updated_by_id' },
        { table: 'plan_history', column: 'changed_by_id' },
        { table: 'operational_data', column: 'created_by' },
        { table: 'manual_entries', column: 'entered_by' },
        { table: 'initial_balances', column: 'entered_by' },
        { table: 'monthly_plans', column: 'created_by_id' },
      ];

      for (const item of reassignMap) {
        await manager.query(
          `UPDATE ${item.table} SET ${item.column} = $1 WHERE ${item.column} = $2`,
          [targetUserId, id]
        );
      }

      await manager.delete(User, { id });
    });

    await recordAuditLog({
      action: 'USER_REASSIGN_DELETE',
      userId: req.user?.id,
      entityType: 'user',
      entityId: id,
      details: { targetUserId },
      req,
    });

    logger.info(`User ${id} reassigned to ${targetUserId} and deleted`);
    res.json({ message: 'Пользователь удален, связанные записи переназначены' });
  } catch (error) {
    next(error);
  }
};

export const resetUserPassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const user = await userRepository.findOne({ where: { id } });
    if (!user) {
      const error: any = new Error('User not found');
      error.statusCode = 404;
      throw error;
    }

    const temporaryPassword = crypto.randomBytes(8).toString('base64url');
    user.passwordHash = await bcrypt.hash(temporaryPassword, 12);
    await userRepository.save(user);

    void sendInvitationEmail(user.email, user.fullName, user.role, temporaryPassword)
      .catch((mailError) => {
        logger.warn(`Password reset email failed for user ${user.id}`, mailError as any);
      });

    await recordAuditLog({
      action: 'USER_PASSWORD_RESET',
      userId: req.user?.id,
      entityType: 'user',
      entityId: user.id,
      req,
    });

    res.json({
      message: 'Пароль пользователя сброшен',
      temporaryPassword,
    });
  } catch (error) {
    next(error);
  }
};

export const deleteUser = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;

    const user = await userRepository.findOne({ where: { id } });
    if (!user) {
      const error: any = new Error('User not found');
      error.statusCode = 404;
      throw error;
    }

    try {
      // Try to delete the user
      await userRepository.remove(user);
      
      logger.info(`User deleted: ${id}`);
      await recordAuditLog({
        action: 'USER_DELETED',
        userId: req.user?.id,
        entityType: 'user',
        entityId: id,
        req,
      });
      res.json({ message: 'User deleted' });
    } catch (deleteError: any) {
      // Check if it's a foreign key constraint violation
      if (deleteError.code === '23503') {
        const error: any = new Error('Невозможно удалить пользователя, так как у него есть связанные данные в системе. Сначала удалите или переназначьте связанные записи.');
        error.statusCode = 409;
        throw error;
      }
      throw deleteError;
    }
  } catch (error) {
    next(error);
  }
};

export const getAuditLog = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { userId, action, startDate, endDate, limit, tzOffsetMinutes } = req.query;
    const where: any = {};

    if (userId) where.userId = String(userId);
    if (action) where.action = String(action);

    const offsetMinutesRaw = Number(tzOffsetMinutes);
    const offsetMinutes = Number.isFinite(offsetMinutesRaw) ? offsetMinutesRaw : 0;

    const normalizeDate = (value: string, mode: 'start' | 'end') => {
      const trimmed = value.trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
        const [year, month, day] = trimmed.split('-').map(Number);
        const baseUtc = mode === 'start'
          ? Date.UTC(year, month - 1, day, 0, 0, 0, 0)
          : Date.UTC(year, month - 1, day, 23, 59, 59, 999);
        return new Date(baseUtc + offsetMinutes * 60_000);
      }
      return new Date(trimmed);
    };

    if (startDate && endDate) {
      where.createdAt = Between(
        normalizeDate(String(startDate), 'start'),
        normalizeDate(String(endDate), 'end')
      );
    } else if (startDate) {
      where.createdAt = MoreThanOrEqual(normalizeDate(String(startDate), 'start'));
    } else if (endDate) {
      where.createdAt = LessThanOrEqual(normalizeDate(String(endDate), 'end'));
    }

    const safeLimit = Math.min(Number(limit) || 200, 1000);
    const logs = await auditLogRepository.find({
      where,
      order: { createdAt: 'DESC' },
      take: safeLimit,
    });

    res.json(logs);
  } catch (error) {
    next(error);
  }
};

export const getSystemStats = async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const userCount = await userRepository.count();
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const [dailyReports, monthlyReports] = await Promise.all([
      reportRepository.count({
        where: {
          type: 'daily',
          generatedAt: MoreThanOrEqual(startOfDay),
        },
      }),
      reportRepository.count({
        where: {
          type: 'monthly',
          generatedAt: MoreThanOrEqual(startOfMonth),
        },
      }),
    ]);

    const lastBackupSetting = await appSettingRepository.findOne({ where: { key: 'last_backup' } });
    const uptimeSeconds = Math.floor(process.uptime());

    res.json({
      users: userCount,
      activeSessions: planWebSocketService.getClientCount(),
      dailyReports,
      monthlyReports,
      lastBackup: lastBackupSetting?.value ?? null,
      uptime: uptimeSeconds,
    });
  } catch (error) {
    next(error);
  }
};

export const getAppSettings = async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const appTitle = await appSettingRepository.findOne({ where: { key: 'app_title' } });
    res.json({
      appTitle: appTitle?.value || 'Логистика & Отчетность',
    });
  } catch (error) {
    next(error);
  }
};

export const updateAppSettings = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const raw = (req.body?.appTitle ?? '').toString().trim();
    const appTitle = raw.length > 0 ? raw : 'Логистика & Отчетность';

    let setting = await appSettingRepository.findOne({ where: { key: 'app_title' } });
    if (!setting) {
      setting = appSettingRepository.create({
        key: 'app_title',
        value: appTitle,
      });
    } else {
      setting.value = appTitle;
    }

    await appSettingRepository.save(setting);
    res.json({ message: 'Настройки приложения обновлены', appTitle: setting.value });
  } catch (error) {
    next(error);
  }
};
