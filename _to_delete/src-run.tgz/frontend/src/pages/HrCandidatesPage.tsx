import { FormEvent, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Alert, Button, MenuItem, TextField } from '@mui/material';
import {
  addHhCandidateEvent,
  createHhCandidate,
  getHhCandidate,
  getHhCandidates,
  getHhVacancies,
  importFarpostResume,
  updateHhCandidate,
  getHiringRequests,
  submitCandidatesToRequest,
} from '../services/hh.api';
import type {
  HhCandidateDto,
  HhCandidateEventDto,
  HhCandidateStage,
  HhCandidateStatus,
  HhFarpostImportResult,
  HhHiringRequestDto,
  HhVacancyDto,
} from '../types/hh';
import { useAuthStore } from '../store/auth-store';
import { canManageHrVacancies, canViewHrCandidatePii } from '../utils/rolePermissions';
import { extractApiError } from '../utils/apiError';
import '../styles/hr-cabinet.css';

const PER_PAGE = 50;

const stageLabels: Record<HhCandidateStage, string> = {
  new: 'Новый отклик',
  screening: 'Скрининг',
  phone_interview: 'Телефонное интервью',
  submitted_to_manager: 'У руководителя',
  manager_interview: 'Интервью с заказчиком',
  offer: 'Оффер',
  hired: 'Принят',
  rejected: 'Отказ',
};

const statusLabels: Record<HhCandidateStatus, string> = {
  active: 'В работе',
  reserve: 'Кадровый резерв',
  hired: 'Принят',
  rejected: 'Отказ',
};

const emptyForm = {
  fullName: '',
  position: '',
  phone: '',
  email: '',
  city: '',
  desiredSalary: '',
  vacancyId: '',
  skillsText: '',
};

const emptyFarpostForm = {
  rawText: '',
  sourceUrl: '',
  vacancyId: '',
};

const farpostLocations = [
  { value: '', label: 'Все города', path: '/rabota/resume/' },
  { value: 'vladivostok', label: 'Владивосток', path: '/vladivostok/rabota/resume/' },
  { value: 'ussuriisk', label: 'Уссурийск', path: '/ussuriisk/rabota/resume/' },
  { value: 'nahodka', label: 'Находка', path: '/nahodka/rabota/resume/' },
  { value: 'khabarovsk', label: 'Хабаровск', path: '/khabarovsk/rabota/resume/' },
  { value: 'yuzhno-sakhalinsk', label: 'Южно-Сахалинск', path: '/yuzhno-sakhalinsk/rabota/resume/' },
  { value: 'custom', label: 'Свой город', path: '' },
];

const emptyFarpostSearch = {
  query: '',
  location: '',
  customLocation: '',
  salary: '',
};

const eventTypeLabels: Record<HhCandidateEventDto['type'], string> = {
  created: 'Создание',
  stage_changed: 'Этап',
  status_changed: 'Статус',
  comment: 'Комментарий',
  interview_scheduled: 'Интервью',
  email_sent: 'Письмо',
  imported: 'Импорт',
};

const formatDateTime = (value?: string | null) => {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export default function HrCandidatesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const role = useAuthStore((state) => state.user?.role);
  // Роли отчётности (director, general_director, financer) допущены к воронке,
  // но не к ПДн: сервер обезличивает данные, клиент прячет соответствующий UI.
  const canSeePii = canViewHrCandidatePii(role);
  const canManage = canManageHrVacancies(role);
  const [items, setItems] = useState<HhCandidateDto[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [vacancies, setVacancies] = useState<HhVacancyDto[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [farpostForm, setFarpostForm] = useState(emptyFarpostForm);
  const [farpostSearch, setFarpostSearch] = useState(emptyFarpostSearch);
  const [farpostOpen, setFarpostOpen] = useState(false);
  const [farpostResult, setFarpostResult] = useState<HhFarpostImportResult | null>(null);
  const [farpostLoading, setFarpostLoading] = useState(false);
  const [selectedCandidateId, setSelectedCandidateId] = useState<string | null>(null);
  const [selectedCandidateDetails, setSelectedCandidateDetails] = useState<HhCandidateDto | null>(null);
  const [candidateDetailsLoading, setCandidateDetailsLoading] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [interviewForm, setInterviewForm] = useState({ dueAt: '', comment: '' });
  const [requests, setRequests] = useState<HhHiringRequestDto[]>([]);
  const [submitForm, setSubmitForm] = useState({ requestId: '', note: '' });
  const [submitInfo, setSubmitInfo] = useState<string | null>(null);
  const [q, setQ] = useState('');
  const [stage, setStage] = useState<HhCandidateStage | ''>('');
  const [error, setError] = useState<string | null>(null);

  const load = (nextPage = page) => {
    setIsLoading(true);
    Promise.all([
      getHhCandidates({ q: q || undefined, stage, page: nextPage, perPage: PER_PAGE }),
      getHhVacancies({ status: 'open', perPage: 200 }),
    ])
      .then(([candidatesResponse, vacanciesResponse]) => {
        setItems(candidatesResponse.data.items);
        setTotal(candidatesResponse.data.total);
        setPage(candidatesResponse.data.page);
        setVacancies(vacanciesResponse.data.items);
      })
      .catch((err) => setError(extractApiError(err, 'Не удалось загрузить кандидатов')))
      .finally(() => setIsLoading(false));
  };

  // Открытые заявки нужны, чтобы отправить кандидата автору заявки.
  useEffect(() => {
    if (!canManage) return;
    getHiringRequests()
      .then((response) => setRequests(response.data.filter((item) => item.status === 'new' || item.status === 'in_progress')))
      .catch(() => setRequests([]));
  }, [canManage]);

  useEffect(() => {
    load(0);
  }, []);

  // Deep link на карточку кандидата: /hr/candidates?candidateId=...
  useEffect(() => {
    const candidateId = searchParams.get('candidateId');
    if (!candidateId) return;
    setSelectedCandidateId(candidateId);
    const next = new URLSearchParams(searchParams);
    next.delete('candidateId');
    setSearchParams(next, { replace: true });
  }, [searchParams, setSearchParams]);

  useEffect(() => {
    if (!selectedCandidateId) {
      setSelectedCandidateDetails(null);
      return;
    }
    setCandidateDetailsLoading(true);
    getHhCandidate(selectedCandidateId)
      .then((response) => setSelectedCandidateDetails(response.data))
      .catch((err) => setError(extractApiError(err, 'Не удалось загрузить карточку кандидата')))
      .finally(() => setCandidateDetailsLoading(false));
  }, [selectedCandidateId]);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    try {
      await createHhCandidate({
        fullName: form.fullName,
        position: form.position || null,
        phone: form.phone || null,
        email: form.email || null,
        city: form.city || null,
        desiredSalary: form.desiredSalary ? Number(form.desiredSalary) : null,
        vacancyId: form.vacancyId || null,
        skillsText: form.skillsText || null,
        currentStage: 'new',
        status: 'active',
        source: 'manual',
      });
      setForm(emptyForm);
      load();
    } catch (err) {
      setError(extractApiError(err, 'Не удалось создать кандидата'));
    }
  };

  const importFarpost = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    setFarpostResult(null);
    setFarpostLoading(true);
    try {
      const response = await importFarpostResume({
        rawText: farpostForm.rawText,
        sourceUrl: farpostForm.sourceUrl || null,
        vacancyId: farpostForm.vacancyId || null,
      });
      setFarpostResult(response.data);
      setFarpostForm(emptyFarpostForm);
      load();
    } catch (err) {
      setError(extractApiError(err, 'Не удалось импортировать резюме FarPost'));
    } finally {
      setFarpostLoading(false);
    }
  };

  const buildFarpostSearchUrl = () => {
    const selectedLocation = farpostLocations.find((location) => location.value === farpostSearch.location) ?? farpostLocations[0];
    const customPath = farpostSearch.customLocation
      ? `/${farpostSearch.customLocation.trim().replace(/^\/+|\/+$/g, '')}/rabota/resume/`
      : selectedLocation.path;
    const path = selectedLocation.value === 'custom' ? customPath : selectedLocation.path;
    const url = new URL(path || '/rabota/resume/', 'https://www.farpost.ru');
    if (farpostSearch.query.trim()) url.searchParams.set('query', farpostSearch.query.trim());
    return url.toString();
  };

  const openFarpostSearch = () => {
    window.open(buildFarpostSearchUrl(), '_blank', 'noopener,noreferrer');
  };

  const getCandidateVacancyOptions = (candidate: HhCandidateDto) => {
    if (!candidate.vacancyId || vacancies.some((vacancy) => vacancy.id === candidate.vacancyId)) return vacancies;
    return [
      ...vacancies,
      {
        id: candidate.vacancyId,
        title: candidate.vacancyTitle || 'Текущая вакансия',
      } as HhVacancyDto,
    ];
  };

  const changeCandidate = async (
    id: string,
    patch: { currentStage?: HhCandidateStage; status?: HhCandidateStatus; vacancyId?: string | null },
  ) => {
    setError(null);
    try {
      const response = await updateHhCandidate(id, patch);
      if (selectedCandidateId === id) {
        setSelectedCandidateDetails(response.data);
      }
      load();
    } catch (err) {
      setError(extractApiError(err, 'Не удалось обновить кандидата'));
    }
  };

  const addComment = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedCandidateId || !commentText.trim()) return;
    setError(null);
    try {
      await addHhCandidateEvent(selectedCandidateId, {
        type: 'comment',
        title: 'Комментарий HR',
        comment: commentText.trim(),
      });
      setCommentText('');
      const response = await getHhCandidate(selectedCandidateId);
      setSelectedCandidateDetails(response.data);
      load();
    } catch (err) {
      setError(extractApiError(err, 'Не удалось сохранить комментарий'));
    }
  };

  const scheduleInterview = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedCandidateId || !interviewForm.dueAt) return;
    setError(null);
    try {
      await addHhCandidateEvent(selectedCandidateId, {
        type: 'interview_scheduled',
        title: 'Запланировано интервью',
        comment: interviewForm.comment || null,
        dueAt: new Date(interviewForm.dueAt).toISOString(),
      });
      setInterviewForm({ dueAt: '', comment: '' });
      const response = await getHhCandidate(selectedCandidateId);
      setSelectedCandidateDetails(response.data);
      load();
    } catch (err) {
      setError(extractApiError(err, 'Не удалось запланировать интервью'));
    }
  };

  const sendToRequestAuthor = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedCandidateId || !submitForm.requestId) return;
    setError(null);
    setSubmitInfo(null);
    try {
      const response = await submitCandidatesToRequest(submitForm.requestId, {
        candidateIds: [selectedCandidateId],
        recruiterNote: submitForm.note || null,
      });
      setSubmitInfo(response.data.submitted > 0
        ? 'Кандидат отправлен автору заявки на рассмотрение'
        : 'Этот кандидат уже был отправлен по выбранной заявке');
      setSubmitForm({ requestId: '', note: '' });
      const refreshed = await getHhCandidate(selectedCandidateId);
      setSelectedCandidateDetails(refreshed.data);
    } catch (err) {
      setError(extractApiError(err, 'Не удалось отправить кандидата автору заявки'));
    }
  };

  const selectedCandidate = selectedCandidateDetails ?? items.find((item) => item.id === selectedCandidateId) ?? null;

  return (
    <div className="hr-page">
      <section className="hr-page__header">
        <div>
          <h1 className="hr-page__title">Кандидаты</h1>
          <p className="hr-page__subtitle">Единый цифровой профиль, воронка, кадровый резерв и история взаимодействий.</p>
        </div>
      </section>
      {error && <Alert severity="warning">{error}</Alert>}
      {canManage && (
      <section className="hr-import">
        <div className="hr-import__summary">
          <div>
            <strong>FarPost</strong>
            <span>Быстрый поиск кандидатов на FarPost с сохранением найденного резюме в Report.</span>
          </div>
          <Button variant={farpostOpen ? 'contained' : 'outlined'} onClick={() => setFarpostOpen((value) => !value)}>
            {farpostOpen ? 'Свернуть' : 'Найти'}
          </Button>
        </div>
        {farpostOpen && (
          <div className="hr-import__workspace">
            <div className="hr-import__panel hr-import__panel--primary">
              <div className="hr-import__step">1</div>
              <div className="hr-import__panel-title">Найти кандидата на FarPost</div>
              <div className="hr-import__hint">Заполните параметры и откройте FarPost. Поиск откроется в новой вкладке.</div>
              <div className="hr-import__search-grid">
                <TextField
                  label="Кого ищем"
                  size="small"
                  value={farpostSearch.query}
                  onChange={(e) => setFarpostSearch({ ...farpostSearch, query: e.target.value })}
                  placeholder="водитель, кладовщик..."
                />
                <TextField
                  select
                  label="География"
                  size="small"
                  value={farpostSearch.location}
                  onChange={(e) => setFarpostSearch({ ...farpostSearch, location: e.target.value })}
                >
                  {farpostLocations.map((location) => <MenuItem key={location.label} value={location.value}>{location.label}</MenuItem>)}
                </TextField>
                <TextField
                  label="Ориентир ЗП"
                  size="small"
                  type="number"
                  value={farpostSearch.salary}
                  onChange={(e) => setFarpostSearch({ ...farpostSearch, salary: e.target.value })}
                  placeholder="для заметки"
                />
              </div>
              {farpostSearch.location === 'custom' && (
                <TextField
                  label="Адрес города в FarPost"
                  size="small"
                  value={farpostSearch.customLocation}
                  onChange={(e) => setFarpostSearch({ ...farpostSearch, customLocation: e.target.value })}
                  placeholder="например: khabarovsk"
                />
              )}
              <div className="hr-import__url">{buildFarpostSearchUrl()}</div>
              <Button variant="contained" onClick={openFarpostSearch}>Открыть FarPost</Button>
            </div>
            <div className="hr-import__panel hr-import__panel--primary">
              <div className="hr-import__step">2</div>
              <div className="hr-import__panel-title">Установить расширение Chrome</div>
              <div className="hr-import__hint">
                Один раз загрузите расширение Report FarPost Import и войдите в Report через его иконку.
              </div>
              <div className="hr-import__install-box">
                <code>browser-extensions/farpost-report-import</code>
                <span>Chrome → Extensions → Developer mode → Load unpacked → выбрать эту папку.</span>
              </div>
            </div>
            <div className="hr-import__panel hr-import__panel--primary">
              <div className="hr-import__step">3</div>
              <div className="hr-import__panel-title">Сохранить найденного</div>
              <div className="hr-import__hint">
                На FarPost откройте конкретное резюме. Расширение покажет кнопку "Сохранить в Report" внизу справа. Нажмите её и обновите список.
              </div>
              <Button variant="outlined" onClick={() => load(0)}>Обновить список</Button>
            </div>
            <div className="hr-import__note">
              Не храним логин и пароль FarPost: рекрутер работает в своем браузере, а Report забирает только выбранное резюме.
            </div>
            <details className="hr-import__manual">
              <summary>Ручной импорт, если кнопка браузера не сработала</summary>
              <form className="hr-import__manual-form" onSubmit={importFarpost}>
                <div className="hr-import__search-grid">
                  <TextField
                    select
                    label="Вакансия"
                    size="small"
                    value={farpostForm.vacancyId}
                    onChange={(e) => setFarpostForm({ ...farpostForm, vacancyId: e.target.value })}
                  >
                    <MenuItem value="">Без вакансии</MenuItem>
                    {vacancies.map((vacancy) => <MenuItem key={vacancy.id} value={vacancy.id}>{vacancy.title}</MenuItem>)}
                  </TextField>
                  <TextField
                    label="Ссылка на резюме"
                    size="small"
                    value={farpostForm.sourceUrl}
                    onChange={(e) => setFarpostForm({ ...farpostForm, sourceUrl: e.target.value })}
                    placeholder="https://www.farpost.ru/..."
                  />
                </div>
                <TextField
                  className="hr-import__text"
                  label="Данные страницы резюме"
                  size="small"
                  multiline
                  minRows={4}
                  value={farpostForm.rawText}
                  onChange={(e) => setFarpostForm({ ...farpostForm, rawText: e.target.value })}
                  placeholder="Скопируйте текст страницы резюме"
                  required
                />
                <div className="hr-import__footer">
                  <span>Report распознает поля, проверит дубли и сохранит источник в истории.</span>
                  <Button type="submit" variant="contained" disabled={farpostLoading}>
                    {farpostLoading ? 'Сохраняю...' : 'Импортировать'}
                  </Button>
                </div>
              </form>
            </details>
          </div>
        )}
        {farpostResult && (
          <div className="hr-import__result">
            <strong>{farpostResult.candidate.fullName}</strong>
            <span>
              {farpostResult.parsed.position || 'Должность не распознана'}
              {farpostResult.parsed.city ? `, ${farpostResult.parsed.city}` : ''}
            </span>
            {farpostResult.duplicates.length > 0 && (
              <small>Возможные дубли: {farpostResult.duplicates.map((candidate) => candidate.fullName).join(', ')}</small>
            )}
          </div>
        )}
      </section>
      )}
      {canManage && (
      <form className="hr-page__form" onSubmit={submit}>
        <TextField label="ФИО" size="small" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
        <TextField label="Должность" size="small" value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} />
        <TextField label="Телефон" size="small" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <TextField label="Email" size="small" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <TextField label="Город" size="small" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        <TextField label="Желаемая ЗП" size="small" type="number" value={form.desiredSalary} onChange={(e) => setForm({ ...form, desiredSalary: e.target.value })} />
        <TextField select label="Вакансия" size="small" value={form.vacancyId} onChange={(e) => setForm({ ...form, vacancyId: e.target.value })}>
          <MenuItem value="">Без вакансии</MenuItem>
          {vacancies.map((vacancy) => <MenuItem key={vacancy.id} value={vacancy.id}>{vacancy.title}</MenuItem>)}
        </TextField>
        <TextField className="hr-page__form-wide" label="Навыки" size="small" value={form.skillsText} onChange={(e) => setForm({ ...form, skillsText: e.target.value })} />
        <Button type="submit" variant="contained">Добавить</Button>
      </form>
      )}
      <section className="hr-page__filters">
        <TextField label="Поиск" size="small" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') load(0); }} />
        <TextField select label="Этап" size="small" value={stage} onChange={(e) => setStage(e.target.value as HhCandidateStage | '')}>
          <MenuItem value="">Все</MenuItem>
          {Object.entries(stageLabels).map(([value, label]) => <MenuItem key={value} value={value}>{label}</MenuItem>)}
        </TextField>
        <Button variant="outlined" onClick={() => load(0)}>Применить</Button>
      </section>
      <section className="hr-page__table-shell">
        <table className="hr-page__table">
          <thead>
            <tr>
              <th>Кандидат</th>
              <th>Источник</th>
              {canSeePii && <th>Контакты</th>}
              <th>Вакансия</th>
              <th>Город</th>
              <th>ЗП</th>
              <th>Этап</th>
              <th>Статус</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr
                key={item.id}
                className={selectedCandidateId === item.id ? 'hr-page__table-row--selected' : undefined}
                onDoubleClick={() => setSelectedCandidateId(item.id)}
              >
                <td><strong>{item.fullName}</strong><small>{item.position || 'Должность не указана'}</small></td>
                <td>{item.source === 'farpost' ? 'FarPost' : item.source === 'hh' ? 'hh.ru' : 'Вручную'}</td>
                {canSeePii && <td><span>{item.phone || '—'}</span><small>{item.email || ''}</small></td>}
                <td>
                  {canManage ? (
                    <select
                      className="hr-page__vacancy-select"
                      value={item.vacancyId || ''}
                      onChange={(e) => changeCandidate(item.id, { vacancyId: e.target.value || null })}
                    >
                      <option value="">Без вакансии</option>
                      {getCandidateVacancyOptions(item).map((vacancy) => (
                        <option key={vacancy.id} value={vacancy.id}>{vacancy.title}</option>
                      ))}
                    </select>
                  ) : (item.vacancyTitle || '—')}
                </td>
                <td>{item.city || '—'}</td>
                <td>{item.desiredSalary ? `${item.desiredSalary} \u20BD` : '—'}</td>
                <td>
                  {canManage ? (
                    <select value={item.currentStage} onChange={(e) => changeCandidate(item.id, { currentStage: e.target.value as HhCandidateStage })}>
                      {Object.entries(stageLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                    </select>
                  ) : (<span className="hr-page__status">{stageLabels[item.currentStage]}</span>)}
                </td>
                <td>
                  {canManage ? (
                    <select value={item.status} onChange={(e) => changeCandidate(item.id, { status: e.target.value as HhCandidateStatus })}>
                      {Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                    </select>
                  ) : (<span className="hr-page__status">{statusLabels[item.status]}</span>)}
                </td>
                <td>
                  <Button
                    size="small"
                    variant={selectedCandidateId === item.id ? 'contained' : 'text'}
                    onClick={() => setSelectedCandidateId(item.id)}
                  >
                    {canSeePii ? 'Резюме' : 'Открыть'}
                  </Button>
                </td>
              </tr>
            ))}
            {isLoading && items.length === 0 && (
              <tr><td colSpan={canSeePii ? 9 : 8} className="hr-page__empty">Загрузка...</td></tr>
            )}
            {!isLoading && items.length === 0 && (
              <tr><td colSpan={canSeePii ? 9 : 8} className="hr-page__empty">Кандидатов пока нет.</td></tr>
            )}
          </tbody>
        </table>
      </section>
      <section className="hr-page__paging">
        <span>Всего: {total}</span>
        <Button size="small" variant="outlined" disabled={page <= 0 || isLoading} onClick={() => load(page - 1)}>Назад</Button>
        <span>{page + 1} / {Math.max(1, Math.ceil(total / PER_PAGE))}</span>
        <Button
          size="small"
          variant="outlined"
          disabled={page + 1 >= Math.max(1, Math.ceil(total / PER_PAGE)) || isLoading}
          onClick={() => load(page + 1)}
        >
          Вперёд
        </Button>
      </section>
      {selectedCandidate && <button className="hr-resume-drawer__outside" type="button" aria-label="Закрыть резюме" onClick={() => setSelectedCandidateId(null)} />}
      <aside className={`hr-resume-drawer${selectedCandidate ? ' hr-resume-drawer--open' : ''}`} role="dialog" aria-modal="false">
        {selectedCandidate && (
          <>
            <div className="hr-resume-drawer__header">
              <div>
                <strong>{selectedCandidate.fullName}</strong>
                <span>{selectedCandidate.position || 'Должность не указана'}</span>
              </div>
              <Button variant="text" onClick={() => setSelectedCandidateId(null)}>Закрыть</Button>
            </div>
            <div className="hr-resume-drawer__meta">
              <span>{selectedCandidate.source === 'farpost' ? 'FarPost' : selectedCandidate.source === 'hh' ? 'hh.ru' : 'Вручную'}</span>
              <span>{selectedCandidate.city || 'Город не указан'}</span>
              <span>{selectedCandidate.desiredSalary ? `${selectedCandidate.desiredSalary} \u20BD` : 'ЗП не указана'}</span>
              {canSeePii
                ? <span>{selectedCandidate.phone || selectedCandidate.email ? [selectedCandidate.phone, selectedCandidate.email].filter(Boolean).join(' · ') : 'Контакты не открыты'}</span>
                : <span>Персональные данные скрыты для вашей роли</span>}
            </div>
            <div className="hr-resume-drawer__body">
              {candidateDetailsLoading && <div className="hr-page__empty">Загрузка карточки...</div>}
              <section>
                <h2>Опыт</h2>
                <pre>{selectedCandidate.experienceText || 'Нет данных'}</pre>
              </section>
              <section>
                <h2>Образование</h2>
                <pre>{selectedCandidate.educationText || 'Нет данных'}</pre>
              </section>
              <section>
                <h2>Навыки</h2>
                <pre>{selectedCandidate.skillsText || 'Нет данных'}</pre>
              </section>
              <section>
                <h2>Комментарий</h2>
                <form className="hr-candidate-action" onSubmit={addComment}>
                  <TextField
                    size="small"
                    multiline
                    minRows={3}
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Комментарий по кандидату, результат звонка, причина отказа..."
                  />
                  <Button type="submit" variant="contained" disabled={!commentText.trim()}>Добавить</Button>
                </form>
              </section>
              {canManage && (
                <section>
                  <h2>Отправить заказчику</h2>
                  {requests.length === 0 ? (
                    <p className="hr-page__empty">Открытых заявок на подбор нет.</p>
                  ) : (
                    <form className="hr-candidate-action" onSubmit={sendToRequestAuthor}>
                      <TextField
                        select
                        size="small"
                        label="Заявка на подбор"
                        value={submitForm.requestId}
                        onChange={(e) => setSubmitForm({ ...submitForm, requestId: e.target.value })}
                      >
                        {requests.map((request) => (
                          <MenuItem key={request.id} value={request.id}>
                            {request.position}
                            {request.createdByName ? ` — ${request.createdByName}` : ''}
                          </MenuItem>
                        ))}
                      </TextField>
                      <TextField
                        size="small"
                        label="Почему этот кандидат"
                        value={submitForm.note}
                        onChange={(e) => setSubmitForm({ ...submitForm, note: e.target.value })}
                      />
                      <Button type="submit" variant="contained" disabled={!submitForm.requestId}>
                        Отправить на рассмотрение
                      </Button>
                    </form>
                  )}
                  {submitInfo && <Alert severity="success" onClose={() => setSubmitInfo(null)}>{submitInfo}</Alert>}
                  <p className="hr-submission__contacts">
                    Автор заявки увидит ФИО, фото, возраст и профессиональную часть резюме.
                    Контакты кандидата останутся только у вас.
                  </p>
                </section>
              )}
              <section>
                <h2>Интервью</h2>
                <form className="hr-candidate-action" onSubmit={scheduleInterview}>
                  <TextField
                    size="small"
                    type="datetime-local"
                    label="Дата и время"
                    InputLabelProps={{ shrink: true }}
                    value={interviewForm.dueAt}
                    onChange={(e) => setInterviewForm({ ...interviewForm, dueAt: e.target.value })}
                  />
                  <TextField
                    size="small"
                    value={interviewForm.comment}
                    onChange={(e) => setInterviewForm({ ...interviewForm, comment: e.target.value })}
                    placeholder="Формат, участники, ссылка на звонок"
                  />
                  <Button type="submit" variant="outlined" disabled={!interviewForm.dueAt}>Запланировать</Button>
                </form>
              </section>
              <section>
                <h2>История</h2>
                <div className="hr-candidate-timeline">
                  {(selectedCandidate.events ?? []).length > 0 ? selectedCandidate.events?.map((event) => (
                    <article key={event.id}>
                      <div>
                        <strong>{event.title}</strong>
                        <span>{eventTypeLabels[event.type]} · {formatDateTime(event.createdAt)}</span>
                      </div>
                      {event.dueAt && <small>Запланировано: {formatDateTime(event.dueAt)}</small>}
                      {event.comment && <p>{event.comment}</p>}
                    </article>
                  )) : <div className="hr-page__empty">История пока пуста.</div>}
                </div>
              </section>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
