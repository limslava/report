import { useEffect, useState } from 'react';
import { Alert, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { getHhConnectionStatus, getHhDashboard } from '../services/hh.api';
import type { HhCandidateStage, HhConnectionDto, HhDashboardDto } from '../types/hh';
import '../styles/hr-cabinet.css';

const stageLabels: Record<HhCandidateStage, string> = {
  new: 'Новый отклик',
  screening: 'Скрининг',
  phone_interview: 'Телефонное интервью',
  submitted_to_manager: 'У руководителя',
  manager_interview: 'Интервью с заказчиком',
  offer: 'Оффер',
  hired: 'Принят',
  rejected: 'Отказ',
};

export default function HrDashboardPage() {
  const navigate = useNavigate();
  const [connection, setConnection] = useState<HhConnectionDto | null>(null);
  const [dashboard, setDashboard] = useState<HhDashboardDto | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    Promise.all([getHhConnectionStatus(), getHhDashboard()])
      .then(([connectionResponse, dashboardResponse]) => {
        setConnection(connectionResponse.data);
        setDashboard(dashboardResponse.data);
      })
      .catch((err) => setError(err?.response?.data?.message || err?.message || 'Не удалось загрузить кабинет HR'))
      .finally(() => setIsLoading(false));
  }, []);

  const metrics = dashboard?.metrics;
  const metricValue = (value: number | undefined) => isLoading ? '...' : String(value ?? 0);

  return (
    <div className="hr-page">
      <section className="hr-page__header">
        <div>
          <h1 className="hr-page__title">Кабинет HR</h1>
          <p className="hr-page__subtitle">Вакансии, отклики, кандидаты, интервью и отчётность по найму.</p>
        </div>
        <span className="hr-page__status">
          {connection?.status === 'active' ? 'hh.ru подключён' : 'hh.ru не подключён'}
        </span>
      </section>
      {error && <Alert severity="warning">{error}</Alert>}
      {!connection?.configured && (
        <Alert severity="info">Интеграция hh.ru ещё не настроена. Пока можно вести вакансии и кандидатов вручную.</Alert>
      )}
      <section className="hr-page__grid">
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.openVacancies)}</div><div className="hr-page__label">Открытых вакансий</div></div>
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.responses)}</div><div className="hr-page__label">Новых откликов</div></div>
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.activeCandidates)}</div><div className="hr-page__label">Кандидатов в работе</div></div>
        <div className="hr-page__card"><div className="hr-page__metric">{metricValue(metrics?.weeklyInterviews)}</div><div className="hr-page__label">Интервью на неделе</div></div>
      </section>
      <section className="hr-page__grid hr-page__grid--wide">
        <div className="hr-page__card">
          <div className="hr-page__section-title">Воронка</div>
          <div className="hr-page__stage-list">
            {isLoading ? <div className="hr-page__empty">Загрузка...</div> : (dashboard?.stages ?? []).length > 0 ? dashboard?.stages.map((item) => (
              <div className="hr-page__stage-row" key={item.stage}>
                <span>{item.label}</span>
                <strong>{item.count}</strong>
              </div>
            )) : <div className="hr-page__empty">Пока нет кандидатов в работе.</div>}
          </div>
        </div>
        <div className="hr-page__card">
          <div className="hr-page__section-title">Последние кандидаты</div>
          <div className="hr-page__stage-list">
            {isLoading ? <div className="hr-page__empty">Загрузка...</div> : (dashboard?.recentCandidates ?? []).length > 0 ? dashboard?.recentCandidates.map((candidate) => (
              <div className="hr-page__stage-row" key={candidate.id}>
                <span>{candidate.fullName}<small>{candidate.vacancyTitle ? ` · ${candidate.vacancyTitle}` : ''}</small></span>
                <strong>{stageLabels[candidate.currentStage]}</strong>
              </div>
            )) : <div className="hr-page__empty">Добавьте первого кандидата вручную или подключите импорт откликов.</div>}
          </div>
        </div>
      </section>
      <section className="hr-page__actions">
        <Button variant="contained" onClick={() => navigate('/hr/vacancies')}>Открыть вакансии</Button>
        <Button variant="outlined" onClick={() => navigate('/hr/candidates')}>Открыть кандидатов</Button>
      </section>
    </div>
  );
}
