import '../styles/hr-cabinet.css';

export default function HrReportsPage() {
  return (
    <div className="hr-page">
      <section className="hr-page__header">
        <div>
          <h1 className="hr-page__title">Отчёты по подбору</h1>
          <p className="hr-page__subtitle">Воронка, сроки закрытия, источники, нагрузка рекрутеров и расходы.</p>
        </div>
      </section>
      <section className="hr-page__table-shell">
        <div className="hr-page__placeholder">Отчётные витрины появятся после накопления вакансий, откликов и статистики.</div>
      </section>
    </div>
  );
}
