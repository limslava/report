import { useState, useEffect, useRef } from 'react';
import {
  Box,
  Alert,
  Autocomplete,
  Collapse,
  Typography,
  Paper,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  IconButton,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  FormHelperText,
  Tooltip,
} from '@mui/material';
import { Add, Edit, Delete, LockReset, SwapHoriz, PowerSettingsNew, Close } from '@mui/icons-material';
import {
  getUsers,
  inviteUser,
  updateUser,
  deleteUser,
  getSystemStats,
  getAuditLog,
  resetUserPasswordByAdmin,
  reassignAndDeleteUserByAdmin,
  getContractTemplateVersions,
  uploadContractTemplateVersion,
  activateContractTemplateVersion,
  type ContractTemplateType,
  type ContractTemplateVersion,
} from '../services/api';
import useNotesUnreadStore from '../store/notes-unread-store';
import { getWarehouseClients, WarehouseClient } from '../services/warehouse.api';

const AdminPage = () => {
  const wsConnected = useNotesUnreadStore((state) => state.wsConnected);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [tabValue, setTabValue] = useState(0);

  const [users, setUsers] = useState<any[]>([]);
  const [_loading, setLoading] = useState(false);
  const [_error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [dbMetrics, setDbMetrics] = useState<any>(null);
  const [redisStatus, setRedisStatus] = useState<string | null>(null);
  const [schedulerStatus, setSchedulerStatus] = useState<any>(null);
  const [dbAlertOpen, setDbAlertOpen] = useState(false);
  const [dbAlertMessage, setDbAlertMessage] = useState('');
  const prevDbErrorsRef = useRef<number | null>(null);
  const [reassignDialogOpen, setReassignDialogOpen] = useState(false);
  const [deletingUser, setDeletingUser] = useState<any>(null);
  const [targetUserId, setTargetUserId] = useState('');
  const [isSavingUser, setIsSavingUser] = useState(false);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditError, setAuditError] = useState<string | null>(null);
  const [warehouseClients, setWarehouseClients] = useState<WarehouseClient[]>([]);
  const [contractTemplates, setContractTemplates] = useState<ContractTemplateVersion[]>([]);
  const [templateUploadType, setTemplateUploadType] = useState<ContractTemplateType>('income_standard');
  const [templateUploadFile, setTemplateUploadFile] = useState<File | null>(null);
  const [templateBusy, setTemplateBusy] = useState(false);
  const [templateError, setTemplateError] = useState<string | null>(null);
  const [templateSuccess, setTemplateSuccess] = useState<string | null>(null);
  const [auditFilters, setAuditFilters] = useState({
    userId: '',
    action: '',
    startDate: '',
    endDate: '',
    limit: '200',
  });
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    role: '',
    timezone: 'Asia/Vladivostok',
    workdayStart: '10:00',
    workdayEnd: '19:00',
    workdays: [1, 2, 3, 4, 5] as number[],
    warehouseClientId: '',
  });

  const weekdayLabels: Record<number, string> = {
    1: 'Пн',
    2: 'Вт',
    3: 'Ср',
    4: 'Чт',
    5: 'Пт',
    6: 'Сб',
    0: 'Вс',
  };

  const contractTemplateTypes: Array<{ value: ContractTemplateType; label: string }> = [
    { value: 'income_standard', label: 'Доходный ТЭУ без ПСР' },
    { value: 'income_with_psr', label: 'Доходный ТЭУ с ПСР' },
    { value: 'income_agency_standard', label: 'Доходный Агентский без ПСР' },
    { value: 'income_agency_with_psr', label: 'Доходный Агентский с ПСР' },
    { value: 'expense', label: 'Расходный' },
    { value: 'addendum', label: 'Доп. соглашение' },
  ];

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [usersRes, statsRes] = await Promise.all([
          getUsers(),
          getSystemStats(),
        ]);
        setUsers(usersRes.data);
        setStats(statsRes.data);
      } catch (err: any) {
        setError(err.message || 'Ошибка загрузки');
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    void getWarehouseClients(false)
      .then((response) => setWarehouseClients(response.data))
      .catch(() => setWarehouseClients([]));
  }, []);

  const loadContractTemplates = async () => {
    try {
      setTemplateError(null);
      const response = await getContractTemplateVersions();
      setContractTemplates(Array.isArray(response.data) ? response.data : []);
    } catch (error: any) {
      setTemplateError(error.response?.data?.message || error.message || 'Не удалось загрузить шаблоны договоров');
    }
  };

  useEffect(() => {
    void loadContractTemplates();
  }, []);

  useEffect(() => {
    let stopped = false;
    const loadDbMetrics = async () => {
      try {
        const response = await fetch('/health/db/metrics', { cache: 'no-store' });
        if (!response.ok) {
          return;
        }
        const data = await response.json();
        if (!stopped) {
          const messages: string[] = [];
          const prevErrors = prevDbErrorsRef.current;
          if (typeof data?.totalErrors === 'number') {
            if (prevErrors !== null && data.totalErrors > prevErrors) {
              messages.push(`DB ошибки увеличились: +${data.totalErrors - prevErrors}`);
            }
            prevDbErrorsRef.current = data.totalErrors;
          }
          if (typeof data?.avgLatencyMs === 'number' && data.avgLatencyMs > 800) {
            messages.push(`Высокая средняя задержка БД: ${data.avgLatencyMs} ms`);
          }
          if (messages.length > 0) {
            setDbAlertMessage(messages.join(' • '));
            setDbAlertOpen(true);
          }
          setDbMetrics(data);
        }
      } catch {
        // ignore
      }
    };

    loadDbMetrics();
    const timer = window.setInterval(loadDbMetrics, 30000);
    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    let stopped = false;
    const loadHealth = async () => {
      try {
        const [redisRes, schedulerRes] = await Promise.all([
          fetch('/health/redis', { cache: 'no-store' }),
          fetch('/health/scheduler', { cache: 'no-store' }),
        ]);

        if (!stopped) {
          const redisData = await redisRes.json().catch(() => ({}));
          setRedisStatus(redisData?.status ?? (redisRes.ok ? 'OK' : 'DOWN'));

          const schedulerData = await schedulerRes.json().catch(() => ({}));
          setSchedulerStatus({ status: schedulerRes.ok ? 'OK' : 'DOWN', ...schedulerData });
        }
      } catch {
        if (!stopped) {
          setRedisStatus('DOWN');
          setSchedulerStatus({ status: 'DOWN' });
        }
      }
    };

    loadHealth();
    const timer = window.setInterval(loadHealth, 30000);
    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, []);

  const roleLabels: Record<string, string> = {
    manager_ktk_vvo: 'Менеджер КТК Владивосток',
    head_ktk_vvo: 'Руководитель КТК Владивосток',
    manager_ktk_mow: 'Менеджер КТК Москва',
    head_ktk_mow: 'Руководитель КТК Москва',
    head_hr: 'Руководитель отдела кадров',
    hr_specialist: 'Специалист отдела кадров',
    hr_recruiter: 'HR-рекрутер',
    garage_head_vvo: 'Начальник гаража Владивосток',
    garage_head: 'Начальник гаража Владивосток',
    manager_auto: 'Менеджер отправки авто',
    manager_rail: 'Менеджер ЖД',
    manager_extra: 'Менеджер доп.услуг',
    manager_to: 'Менеджер ТО авто',
    warehouse_manager_vvo: 'Заведующий складом Владивосток',
    warehouse_manager: 'Руководитель склада',
    warehouse_keeper: 'Кладовщик',
    counterparty_user: 'Представитель контрагента',
    manager_sales: 'Менеджер по продажам',
    head_sales: 'Руководитель отдела продаж',
    director: 'Директор',
    general_director: 'Генеральный директор',
    admin: 'Администратор',
    financer: 'Финансист',
    chief_accountant: 'Главный бухгалтер',
    lawyer: 'Юрист',
    security: 'Руководитель СБ',
    secretary: 'Офис-менеджер',
  };

  const auditActions = [
    { value: '', label: 'Все действия' },
    { value: 'LOGIN', label: 'LOGIN' },
    { value: 'DAILY_REPORT_SAVED', label: 'DAILY_REPORT_SAVED' },
    { value: 'OPERATIONAL_PLAN_SAVED', label: 'OPERATIONAL_PLAN_SAVED' },
    { value: 'WORK_SCHEDULE_SAVED', label: 'WORK_SCHEDULE_SAVED' },
    { value: 'FIN_RESULT_UPDATED', label: 'FIN_RESULT_UPDATED' },
    { value: 'USER_INVITED', label: 'USER_INVITED' },
    { value: 'USER_UPDATED', label: 'USER_UPDATED' },
    { value: 'USER_PASSWORD_RESET', label: 'USER_PASSWORD_RESET' },
    { value: 'USER_REASSIGN_DELETE', label: 'USER_REASSIGN_DELETE' },
    { value: 'USER_DELETED', label: 'USER_DELETED' },
    { value: 'WAREHOUSE_DATES_CORRECTED', label: 'WAREHOUSE_DATES_CORRECTED' },
  ];

  const roles = [
    { value: 'manager_ktk_vvo', label: 'Менеджер КТК Владивосток' },
    { value: 'head_ktk_vvo', label: 'Руководитель КТК Владивосток' },
    { value: 'manager_ktk_mow', label: 'Менеджер КТК Москва' },
    { value: 'head_ktk_mow', label: 'Руководитель КТК Москва' },
    { value: 'head_hr', label: 'Руководитель отдела кадров' },
    { value: 'hr_specialist', label: 'Специалист отдела кадров' },
    { value: 'hr_recruiter', label: 'HR-рекрутер' },
    { value: 'garage_head_vvo', label: 'Начальник гаража Владивосток' },
    { value: 'manager_auto', label: 'Менеджер отправки авто' },
    { value: 'manager_rail', label: 'Менеджер ЖД' },
    { value: 'manager_extra', label: 'Менеджер доп.услуг' },
    { value: 'manager_to', label: 'Менеджер ТО авто' },
    { value: 'warehouse_manager_vvo', label: 'Заведующий складом Владивосток' },
    { value: 'warehouse_manager', label: 'Руководитель склада' },
    { value: 'warehouse_keeper', label: 'Кладовщик' },
    { value: 'counterparty_user', label: 'Представитель контрагента' },
    { value: 'manager_sales', label: 'Менеджер по продажам' },
    { value: 'head_sales', label: 'Руководитель отдела продаж' },
    { value: 'director', label: 'Директор' },
    { value: 'general_director', label: 'Генеральный директор' },
    { value: 'admin', label: 'Администратор' },
    { value: 'financer', label: 'Финансист' },
    { value: 'chief_accountant', label: 'Главный бухгалтер' },
    { value: 'lawyer', label: 'Юрист' },
    { value: 'security', label: 'Руководитель СБ' },
    { value: 'secretary', label: 'Офис-менеджер' },
  ];

  const userNameById = users.reduce<Record<string, string>>((acc, user) => {
    acc[user.id] = user.fullName || user.email || user.id;
    return acc;
  }, {});

  const formatLocalDateTime = (value?: string | null) => {
    if (!value) return '—';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return value;
    return new Intl.DateTimeFormat('ru-RU', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(parsed);
  };

  const formatUptime = (seconds?: number | null) => {
    if (seconds == null) return '—';
    const total = Math.max(0, Math.floor(seconds));
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    if (days > 0) return `${days}д ${hours}ч ${minutes}м`;
    if (hours > 0) return `${hours}ч ${minutes}м`;
    return `${minutes}м`;
  };

  const fileToBase64 = (file: File) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || '').split(',')[1] || '');
    reader.onerror = () => reject(new Error(`Не удалось прочитать файл: ${file.name}`));
    reader.readAsDataURL(file);
  });

  const formatBytes = (value?: number | null) => {
    if (!value) return '—';
    if (value < 1024) return `${value} Б`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} КБ`;
    return `${(value / (1024 * 1024)).toFixed(1)} МБ`;
  };

  const handleUploadContractTemplate = async () => {
    if (!templateUploadFile || templateBusy) return;
    try {
      setTemplateBusy(true);
      setTemplateError(null);
      setTemplateSuccess(null);
      const contentBase64 = await fileToBase64(templateUploadFile);
      await uploadContractTemplateVersion({
        templateType: templateUploadType,
        originalName: templateUploadFile.name,
        contentBase64,
      });
      setTemplateUploadFile(null);
      setTemplateSuccess('Версия шаблона загружена. Активируйте ее, когда будете готовы применять к новым договорам.');
      await loadContractTemplates();
    } catch (error: any) {
      setTemplateError(error.response?.data?.message || error.message || 'Не удалось загрузить шаблон');
    } finally {
      setTemplateBusy(false);
    }
  };

  const handleActivateContractTemplate = async (id: string) => {
    if (templateBusy) return;
    try {
      setTemplateBusy(true);
      setTemplateError(null);
      setTemplateSuccess(null);
      await activateContractTemplateVersion(id);
      setTemplateSuccess('Активная версия шаблона обновлена');
      await loadContractTemplates();
    } catch (error: any) {
      setTemplateError(error.response?.data?.message || error.message || 'Не удалось активировать шаблон');
    } finally {
      setTemplateBusy(false);
    }
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const loadAuditLogs = async () => {
    if (!auditFilters.startDate || !auditFilters.endDate) {
      setAuditError('Выберите "Дата с" и "Дата по", затем нажмите "Обновить".');
      return;
    }
    try {
      setAuditLoading(true);
      setAuditError(null);
      const params: Record<string, any> = {};
      if (auditFilters.userId) params.userId = auditFilters.userId;
      if (auditFilters.action) params.action = auditFilters.action;
      if (auditFilters.startDate) params.startDate = auditFilters.startDate;
      if (auditFilters.endDate) params.endDate = auditFilters.endDate;
      if (auditFilters.limit) params.limit = auditFilters.limit;
      params.tzOffsetMinutes = new Date().getTimezoneOffset();
      const response = await getAuditLog(params);
      setAuditLogs(Array.isArray(response.data) ? response.data : []);
    } catch (err: any) {
      setAuditError(err?.message || 'Не удалось загрузить журнал действий');
    } finally {
      setAuditLoading(false);
    }
  };

  const statsRows = [
    { label: 'Всего пользователей', value: stats?.users ?? '—' },
    { label: 'Активные сессии', value: stats?.activeSessions ?? '—' },
    { label: 'WebSocket (уведомления)', value: wsConnected ? 'CONNECTED' : 'DISCONNECTED', chip: true },
    { label: 'Отчетов сегодня', value: stats?.dailyReports ?? '—' },
    { label: 'Отчетов за месяц', value: stats?.monthlyReports ?? '—' },
    { label: 'DB latency (avg)', value: dbMetrics?.avgLatencyMs != null ? `${dbMetrics.avgLatencyMs} ms` : '—' },
    { label: 'DB ошибки', value: dbMetrics?.totalErrors ?? '—' },
    { label: 'Redis', value: redisStatus ?? '—', chip: true },
    { label: 'Scheduler', value: schedulerStatus?.status ?? '—', chip: true },
    { label: 'Scheduler last run', value: formatLocalDateTime(schedulerStatus?.lastRunAt) },
    { label: 'Последняя ошибка БД', value: dbMetrics?.lastError ? `${dbMetrics.lastError} (${dbMetrics.lastErrorAt ?? '—'})` : '—' },
    { label: 'Последний бэкап', value: stats?.lastBackup ?? '—' },
    { label: 'Uptime', value: formatUptime(stats?.uptime) },
  ];

  const handleOpenDialog = (user: any = null) => {
    setSelectedUser(user);
    if (user) {
      const userWorkdays = String(user.workdays || '1,2,3,4,5')
        .split(',')
        .map((d: string) => Number(d))
        .filter((d: number) => Number.isInteger(d) && d >= 0 && d <= 6);
      setFormData({
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        timezone: user.timezone || 'Asia/Vladivostok',
        workdayStart: user.workdayStart || '10:00',
        workdayEnd: user.workdayEnd || '19:00',
        workdays: userWorkdays.length > 0 ? userWorkdays : [1, 2, 3, 4, 5],
        warehouseClientId: user.warehouseClientId || '',
      });
    } else {
      setFormData({
        email: '',
        fullName: '',
        role: '',
        timezone: 'Asia/Vladivostok',
        workdayStart: '10:00',
        workdayEnd: '19:00',
        workdays: [1, 2, 3, 4, 5],
        warehouseClientId: '',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedUser(null);
    setFormData({
      email: '',
      fullName: '',
      role: '',
      timezone: 'Asia/Vladivostok',
      workdayStart: '10:00',
      workdayEnd: '19:00',
      workdays: [1, 2, 3, 4, 5],
      warehouseClientId: '',
    });
  };

  const handleSaveUser = async () => {
    if (isSavingUser) {
      return;
    }

    const {
      email,
      fullName,
      role,
      timezone,
      workdayStart,
      workdayEnd,
      workdays,
      warehouseClientId,
    } = formData;
    if (!email || !fullName || !role) {
      alert('Заполните все поля');
      return;
    }
    if (role === 'counterparty_user' && !warehouseClientId) {
      alert('Выберите клиента склада для представителя контрагента');
      return;
    }

    try {
      setIsSavingUser(true);
      if (selectedUser) {
        await updateUser(selectedUser.id, {
          email,
          fullName,
          role,
          timezone,
          workdayStart,
          workdayEnd,
          workdays: workdays.join(','),
          warehouseClientId: role === 'counterparty_user' ? warehouseClientId : null,
        });
        alert('Пользователь обновлен');
      } else {
        const invitation = await inviteUser({
          email,
          fullName,
          role,
          warehouseClientId: role === 'counterparty_user' ? warehouseClientId : null,
        });
        if (invitation.data.emailSent) {
          alert('Пользователь добавлен, приглашение отправлено');
        } else {
          alert(
            `Пользователь создан, но письмо отправить не удалось.${
              invitation.data.temporaryPassword
                ? ` Временный пароль: ${invitation.data.temporaryPassword}`
                : ''
            }`,
          );
        }
      }
      
      // Перезагружаем список
      const usersRes = await getUsers();
      setUsers(usersRes.data);
      handleCloseDialog();
    } catch (error: any) {
      alert(`Ошибка: ${error.response?.data?.message || error.message}`);
    } finally {
      setIsSavingUser(false);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm('Удалить пользователя?')) return;
    try {
      await deleteUser(id);
      // Обновляем список
      const usersRes = await getUsers();
      setUsers(usersRes.data);
      alert('Пользователь удален');
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || error.response?.data?.message || error.message;
      alert(`Ошибка удаления: ${errorMessage}`);
    }
  };

  const handleToggleActive = async (user: any) => {
    try {
      await updateUser(user.id, { isActive: !user.isActive });
      const usersRes = await getUsers();
      setUsers(usersRes.data);
    } catch (error: any) {
      alert(`Ошибка изменения статуса: ${error.response?.data?.message || error.message}`);
    }
  };

  const openReassignDeleteDialog = (user: any) => {
    setDeletingUser(user);
    setTargetUserId('');
    setReassignDialogOpen(true);
  };

  const closeReassignDeleteDialog = () => {
    setReassignDialogOpen(false);
    setDeletingUser(null);
    setTargetUserId('');
  };

  const handleReassignDelete = async () => {
    if (!deletingUser || !targetUserId) return;
    try {
      await reassignAndDeleteUserByAdmin(deletingUser.id, targetUserId);
      const usersRes = await getUsers();
      setUsers(usersRes.data);
      closeReassignDeleteDialog();
      alert('Пользователь удален, записи переназначены');
    } catch (error: any) {
      const details = error.response?.data?.details;
      const detailsText = Array.isArray(details) ? details.map((d: any) => `${d.field}: ${d.message}`).join(', ') : '';
      alert(`Ошибка: ${error.response?.data?.message || error.response?.data?.error || error.message}${detailsText ? ` (${detailsText})` : ''}`);
    }
  };

  const handleResetPassword = async (id: string) => {
    if (!confirm('Сбросить пароль пользователя?')) return;
    try {
      const response = await resetUserPasswordByAdmin(id);
      const tempPassword = response.data?.temporaryPassword;
      alert(`Пароль сброшен.${tempPassword ? ` Временный пароль: ${tempPassword}` : ''}`);
    } catch (error: any) {
      alert(`Ошибка сброса пароля: ${error.response?.data?.message || error.message}`);
    }
  };

  return (
    <Box>
      <Collapse in={dbAlertOpen}>
        <Alert
          severity="warning"
          sx={{ mb: 2 }}
          action={(
            <IconButton color="inherit" size="small" onClick={() => setDbAlertOpen(false)}>
              <Close fontSize="small" />
            </IconButton>
          )}
        >
          {dbAlertMessage}
        </Alert>
      </Collapse>
      <Paper sx={{ p: 3, mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="Пользователи системы" />
          <Tab label="Статистика" />
          <Tab label="Журнал действий" />
          <Tab label="Шаблоны договоров" />
        </Tabs>

        {tabValue === 0 && (
          <Box sx={{ pt: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
              <Typography variant="h6">Пользователи системы</Typography>
              <Button
                variant="contained"
                startIcon={<Add />}
                onClick={() => handleOpenDialog()}
              >
                Добавить пользователя
              </Button>
            </Box>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>ФИО</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Роль</TableCell>
                    <TableCell>Организация</TableCell>
                    <TableCell>Статус</TableCell>
                    <TableCell>Действия</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.fullName}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Chip
                          label={roleLabels[user.role] || user.role}
                          size="small"
                          color={user.role === 'admin' ? 'error' : (user.role === 'director' || user.role === 'general_director') ? 'warning' : 'default'}
                        />
                      </TableCell>
                      <TableCell>
                        {user.role === 'counterparty_user'
                          ? (
                            <>
                              <Typography variant="body2">
                                {user.warehouseClient?.nameShort
                                  || user.warehouseClient?.nameFull
                                  || 'Не привязан'}
                              </Typography>
                              {user.warehouseClient?.inn && (
                                <Typography variant="caption" color="text.secondary">
                                  ИНН {user.warehouseClient.inn}
                                </Typography>
                              )}
                            </>
                          )
                          : '—'}
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={user.isActive ? 'Активен' : 'Отключен'}
                          color={user.isActive ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Tooltip title="Редактировать">
                          <IconButton size="small" onClick={() => handleOpenDialog(user)}>
                            <Edit fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Сбросить пароль">
                          <IconButton size="small" onClick={() => handleResetPassword(user.id)}>
                            <LockReset fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title={user.isActive ? 'Деактивировать' : 'Активировать'}>
                          <IconButton size="small" onClick={() => handleToggleActive(user)}>
                            <PowerSettingsNew fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Переназначить и удалить">
                          <IconButton size="small" onClick={() => openReassignDeleteDialog(user)}>
                            <SwapHoriz fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Удалить">
                          <IconButton size="small" onClick={() => handleDeleteUser(user.id)}>
                            <Delete fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        )}

        {tabValue === 1 && (
          <Box sx={{ pt: 3 }}>
            <Typography variant="h6" gutterBottom>
              Статистика
            </Typography>
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' },
                gap: 2,
              }}
            >
              {statsRows.map((row) => (
                <Paper key={row.label} variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="caption" color="text.secondary">
                    {row.label}
                  </Typography>
                  <Box sx={{ mt: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                    {row.chip ? (
                      <Chip
                        label={row.value ?? '—'}
                        size="small"
                        color={
                          row.value === 'OK' || row.value === 'CONNECTED'
                            ? 'success'
                            : row.value === 'DOWN' || row.value === 'DISCONNECTED'
                              ? 'error'
                              : 'default'
                        }
                        sx={{ fontSize: '0.75rem', height: 22 }}
                      />
                    ) : (
                      <Typography sx={{ fontWeight: 600, fontSize: '0.8rem' }}>
                        {row.value ?? '—'}
                      </Typography>
                    )}
                  </Box>
                </Paper>
              ))}
            </Box>
          </Box>
        )}

        {tabValue === 2 && (
          <Box sx={{ pt: 3 }}>
            <Typography variant="h6" gutterBottom>
              Журнал действий
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'flex-end', mb: 2 }}>
              <TextField
                label="Дата с"
                type="date"
                size="small"
                InputLabelProps={{ shrink: true }}
                value={auditFilters.startDate}
                onChange={(e) => setAuditFilters((prev) => ({ ...prev, startDate: e.target.value }))}
              />
              <TextField
                label="Дата по"
                type="date"
                size="small"
                InputLabelProps={{ shrink: true }}
                value={auditFilters.endDate}
                onChange={(e) => setAuditFilters((prev) => ({ ...prev, endDate: e.target.value }))}
              />
              <FormControl size="small" sx={{ minWidth: 220 }}>
                <InputLabel shrink>Пользователь</InputLabel>
                <Select
                  label="Пользователь"
                  value={auditFilters.userId}
                  displayEmpty
                  renderValue={(selected) => {
                    if (!selected) return 'Все пользователи';
                    return userNameById[String(selected)] || String(selected);
                  }}
                  onChange={(e) => setAuditFilters((prev) => ({ ...prev, userId: String(e.target.value) }))}
                >
                  <MenuItem value="">Все пользователи</MenuItem>
                  {users.map((user) => (
                    <MenuItem key={user.id} value={user.id}>
                      {user.fullName} ({user.email})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl size="small" sx={{ minWidth: 220 }}>
                <InputLabel>Действие</InputLabel>
                <Select
                  label="Действие"
                  value={auditFilters.action}
                  onChange={(e) => setAuditFilters((prev) => ({ ...prev, action: String(e.target.value) }))}
                >
                  {auditActions.map((action) => (
                    <MenuItem key={action.value} value={action.value}>
                      {action.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <TextField
                label="Лимит"
                type="number"
                size="small"
                value={auditFilters.limit}
                onChange={(e) => setAuditFilters((prev) => ({ ...prev, limit: e.target.value }))}
                sx={{ width: 120 }}
              />
              <Button variant="contained" onClick={loadAuditLogs} disabled={auditLoading}>
                {auditLoading ? 'Загрузка...' : 'Обновить'}
              </Button>
            </Box>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
              Для загрузки журнала выберите период и нажмите «Обновить».
            </Typography>

            {auditError && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {auditError}
              </Alert>
            )}

            <TableContainer sx={{ overflowX: 'auto' }}>
              <Table size="small" sx={{ minWidth: 900 }}>
                <TableHead>
                  <TableRow>
                    <TableCell>Дата</TableCell>
                    <TableCell>Пользователь</TableCell>
                    <TableCell>Действие</TableCell>
                    <TableCell>Объект</TableCell>
                    <TableCell>Детали</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {auditLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>{formatLocalDateTime(log.createdAt)}</TableCell>
                      <TableCell>{log.userId ? userNameById[log.userId] || log.userId : '—'}</TableCell>
                      <TableCell>{log.action}</TableCell>
                      <TableCell sx={{ maxWidth: 220, wordBreak: 'break-word' }}>
                        {log.entityType ? `${log.entityType}${log.entityId ? `:${log.entityId}` : ''}` : '—'}
                      </TableCell>
                      <TableCell sx={{ maxWidth: 320, wordBreak: 'break-word' }}>
                        <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                          {log.details ? JSON.stringify(log.details) : '—'}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                  {auditLogs.length === 0 && !auditLoading && (
                    <TableRow>
                      <TableCell colSpan={5}>Нет записей</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        )}

        {tabValue === 3 && (
          <Box sx={{ pt: 3 }}>
            <Typography variant="h6" gutterBottom>
              Шаблоны договоров
            </Typography>
            <Alert severity="info" sx={{ mb: 2 }}>
              Новая активная версия применяется только к новым договорам и к черновикам при пересборке документа.
              Уже созданные вложения договоров автоматически не меняются.
            </Alert>
            <Alert severity="warning" sx={{ mb: 2 }}>
              Сейчас автогенерация подключена для доходных типов ТЭУ и Агентский (с ПСР и без ПСР) — нужный шаблон
              выбирается автоматически по виду дохода и признаку ПСР. Остальные типы можно версионировать заранее,
              но они начнут применяться после подключения генераторов для этих видов документов.
            </Alert>

            {templateError && (
              <Alert severity="error" sx={{ mb: 2 }}>{templateError}</Alert>
            )}
            {templateSuccess && (
              <Alert severity="success" sx={{ mb: 2 }}>{templateSuccess}</Alert>
            )}

            <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
              <Typography variant="subtitle1" sx={{ mb: 2 }}>
                Загрузить новую версию
              </Typography>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '260px 1fr auto' }, gap: 2, alignItems: 'center' }}>
                <FormControl fullWidth size="small">
                  <InputLabel>Тип шаблона</InputLabel>
                  <Select
                    label="Тип шаблона"
                    value={templateUploadType}
                    onChange={(event) => setTemplateUploadType(event.target.value as ContractTemplateType)}
                  >
                    {contractTemplateTypes.map((item) => (
                      <MenuItem key={item.value} value={item.value}>{item.label}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <Button variant="outlined" component="label" disabled={templateBusy}>
                  {templateUploadFile ? templateUploadFile.name : 'Выбрать .docx'}
                  <input
                    hidden
                    type="file"
                    accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    onChange={(event) => setTemplateUploadFile(event.target.files?.[0] ?? null)}
                  />
                </Button>
                <Button
                  variant="contained"
                  onClick={handleUploadContractTemplate}
                  disabled={!templateUploadFile || templateBusy}
                >
                  {templateBusy ? 'Загрузка...' : 'Загрузить'}
                </Button>
              </Box>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1.5 }}>
                Обязательные плейсхолдеры для доходного без ПСР: contractNumber, contractDate, counterpartyName,
                inn, legalAddress, bankName, bankBik, bankAccount, correspondentAccount, signerName.
              </Typography>
            </Paper>

            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Тип</TableCell>
                    <TableCell>Версия</TableCell>
                    <TableCell>Файл</TableCell>
                    <TableCell>Плейсхолдеры</TableCell>
                    <TableCell>Загружен</TableCell>
                    <TableCell>Статус</TableCell>
                    <TableCell>Действия</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {contractTemplates.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell>{template.templateLabel}</TableCell>
                      <TableCell>v{template.version}</TableCell>
                      <TableCell>
                        <Typography variant="body2">{template.originalName}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {formatBytes(template.sizeBytes)} · {template.contentSha256.slice(0, 10)}
                        </Typography>
                      </TableCell>
                      <TableCell sx={{ maxWidth: 320 }}>
                        <Typography variant="caption" sx={{ whiteSpace: 'normal' }}>
                          {template.placeholders.length ? template.placeholders.join(', ') : '—'}
                        </Typography>
                      </TableCell>
                      <TableCell>{formatLocalDateTime(template.createdAt)}</TableCell>
                      <TableCell>
                        <Chip
                          size="small"
                          color={template.isActive ? 'success' : 'default'}
                          label={template.isActive ? 'Активна' : 'Архив'}
                        />
                      </TableCell>
                      <TableCell>
                        <Button
                          size="small"
                          variant="outlined"
                          disabled={template.isActive || templateBusy}
                          onClick={() => handleActivateContractTemplate(template.id)}
                        >
                          Активировать
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {contractTemplates.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7}>Версии шаблонов пока не загружены</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        )}
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {selectedUser ? 'Редактирование пользователя' : 'Новый пользователь'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              label="Email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              fullWidth
            />
            <TextField
              label="ФИО"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              fullWidth
            />
            <Autocomplete
              options={roles}
              value={roles.find((role) => role.value === formData.role) ?? null}
              onChange={(_event, value) => setFormData({
                ...formData,
                role: value?.value ?? '',
                warehouseClientId: value?.value === 'counterparty_user'
                  ? formData.warehouseClientId
                  : '',
              })}
              isOptionEqualToValue={(option, value) => option.value === value.value}
              getOptionLabel={(option) => option.label}
              noOptionsText="Роль не найдена"
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Роль"
                  placeholder="Начните вводить название"
                />
              )}
            />
            {formData.role === 'counterparty_user' && (
              <>
                <Alert severity="info">
                  Представитель сможет только просматривать ТС, услуги, начисления и акты выбранной организации.
                  Приёмка, выдача и редактирование ему недоступны.
                </Alert>
                <FormControl fullWidth>
                  <InputLabel>Клиент склада</InputLabel>
                  <Select
                    label="Клиент склада"
                    value={formData.warehouseClientId}
                    onChange={(e) => setFormData({ ...formData, warehouseClientId: e.target.value })}
                  >
                    {warehouseClients.map((client) => (
                      <MenuItem key={client.id} value={client.id}>
                        {client.nameShort || client.nameFull} — {client.inn}
                      </MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    Привязка обязательна и ограничивает данные на сервере.
                  </FormHelperText>
                </FormControl>
                {(() => {
                  const client = warehouseClients.find((item) => item.id === formData.warehouseClientId);
                  if (!client) return null;
                  const label = client.contractNumber
                    ? `Договор № ${client.contractNumber}${client.contractEndDate ? ` до ${client.contractEndDate}` : ''}`
                    : 'Номер договора хранения не указан';
                  if (client.contractStatus === 'expired') {
                    return <Alert severity="error">{label}. Срок договора истёк.</Alert>;
                  }
                  if (client.contractStatus === 'expiring') {
                    return (
                      <Alert severity="warning">
                        {label}. До окончания осталось {client.contractDaysRemaining} дн.
                      </Alert>
                    );
                  }
                  return <Alert severity="success">{label}.</Alert>;
                })()}
              </>
            )}
            <TextField
              label="Часовой пояс"
              value={formData.timezone}
              onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
              fullWidth
              helperText="По умолчанию: Asia/Vladivostok"
            />
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
              <TextField
                label="Начало рабочего дня"
                type="time"
                value={formData.workdayStart}
                onChange={(e) => setFormData({ ...formData, workdayStart: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
              <TextField
                label="Конец рабочего дня"
                type="time"
                value={formData.workdayEnd}
                onChange={(e) => setFormData({ ...formData, workdayEnd: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Box>
            <FormControl fullWidth>
              <InputLabel>Рабочие дни</InputLabel>
              <Select
                multiple
                label="Рабочие дни"
                value={formData.workdays as any}
                onChange={(e) => {
                  const next = (e.target.value as unknown as Array<number | string>).map((v) => Number(v));
                  setFormData({ ...formData, workdays: next });
                }}
                renderValue={(selected) =>
                  (selected as number[])
                    .map((d) => weekdayLabels[d] ?? String(d))
                    .join(', ')
                }
              >
                {Object.entries(weekdayLabels).map(([key, label]) => (
                  <MenuItem key={key} value={Number(key)}>
                    {label}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>По умолчанию: Пн-Пт</FormHelperText>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} disabled={isSavingUser}>
            Отмена
          </Button>
          <Button variant="contained" onClick={handleSaveUser} disabled={isSavingUser}>
            {isSavingUser ? 'Сохранение...' : 'Сохранить'}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={reassignDialogOpen} onClose={closeReassignDeleteDialog} maxWidth="sm" fullWidth>
        <DialogTitle>Переназначить и удалить пользователя</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              label="Удаляемый пользователь"
              value={deletingUser ? `${deletingUser.fullName} (${deletingUser.email})` : ''}
              fullWidth
              InputProps={{ readOnly: true }}
            />
            <FormControl fullWidth>
              <InputLabel>Кому переназначить записи</InputLabel>
              <Select
                label="Кому переназначить записи"
                value={targetUserId}
                onChange={(e) => setTargetUserId(String(e.target.value))}
              >
                {users
                  .filter((u) => u.id !== deletingUser?.id)
                  .map((u) => (
                    <MenuItem key={u.id} value={u.id}>
                      {u.fullName} ({u.email})
                    </MenuItem>
                  ))}
              </Select>
              <FormHelperText>Исторические записи будут перенесены на выбранного пользователя</FormHelperText>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeReassignDeleteDialog}>Отмена</Button>
          <Button variant="contained" color="error" disabled={!targetUserId} onClick={handleReassignDelete}>
            Переназначить и удалить
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AdminPage;
