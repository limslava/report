import crypto from 'crypto';
import { getHhCryptoKey } from '../config/env';

const ALGORITHM = 'aes-256-gcm';

function getKey(): Buffer {
  const raw = getHhCryptoKey();
  if (!raw) {
    const error: any = new Error('HH_CRYPTO_KEY is required to store hh.ru secrets');
    error.statusCode = 500;
    throw error;
  }

  const trimmed = raw.trim();
  if (/^[a-f0-9]{64}$/i.test(trimmed)) {
    return Buffer.from(trimmed, 'hex');
  }

  const decoded = Buffer.from(trimmed, 'base64');
  if (decoded.length === 32) {
    return decoded;
  }

  const error: any = new Error('HH_CRYPTO_KEY must be 32 bytes as base64 or 64 hex characters');
  error.statusCode = 500;
  throw error;
}

export function encryptHhSecret(value: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, getKey(), iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return [iv, authTag, encrypted].map((part) => part.toString('base64url')).join('.');
}

export function decryptHhSecret(payload: string): string {
  const [ivRaw, authTagRaw, encryptedRaw] = payload.split('.');
  if (!ivRaw || !authTagRaw || !encryptedRaw) {
    const error: any = new Error('Invalid encrypted hh.ru secret payload');
    error.statusCode = 500;
    throw error;
  }

  const decipher = crypto.createDecipheriv(ALGORITHM, getKey(), Buffer.from(ivRaw, 'base64url'));
  decipher.setAuthTag(Buffer.from(authTagRaw, 'base64url'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(encryptedRaw, 'base64url')),
    decipher.final(),
  ]);
  return decrypted.toString('utf8');
}

export function maskSecret(value: string | null | undefined): string | null {
  if (!value) return null;
  return '••••••••';
}
